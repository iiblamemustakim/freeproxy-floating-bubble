#!/usr/bin/env bash
# 把 art/ic_launcher.svg 导出成 F-Droid / 应用商店要求的 512x512 图标。
# 依赖 rsvg-convert（brew install librsvg）。
set -euo pipefail

cd "$(dirname "$0")/.."

for locale in en-US zh-CN; do
    out="fastlane/metadata/android/$locale/images/icon.png"
    mkdir -p "$(dirname "$out")"
    rsvg-convert -w 512 -h 512 art/ic_launcher.svg -o "$out"
    echo "→ $out"
done
