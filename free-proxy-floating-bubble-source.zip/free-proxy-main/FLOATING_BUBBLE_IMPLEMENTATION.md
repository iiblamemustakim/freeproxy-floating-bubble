# Floating bubble implementation notes

This source fork adds an optional Android overlay controller while retaining the existing FreeProxy VPN tunnel implementation.

## Added behavior

- A Settings switch enables/disables the floating proxy bubble. Android's **Display over other apps** permission is required.
- The bubble is a foreground overlay service, so it can remain visible when the main Activity is swiped away (subject to Android/HyperOS background-service policy and user force-stop/battery restrictions).
- Tap the bubble to call the existing `FreeProxyVpnService` start/stop actions. It does not implement a second proxy tunnel.
- Long-press opens Connect/Disconnect, Resize, Opacity, Settings, and Close popup actions. Country details are not included in that menu.
- Bubble size cycles through small/medium/large. Opacity has a 20–100% slider.
- Country is derived only from the profile ID reported by the live VPN state. The service resolves that one profile and parses its username; it does not parse usernames from all saved profiles. No IP geolocation is used.
- The parser prioritizes an explicit `cr.XX` username segment and otherwise accepts standalone uppercase ISO alpha-2 tokens. Unknown connected profiles display 💀.
- The Country codes dialog supports case-insensitive partial search by country name or code.

## Build status

The source has not been compiled or device-tested in this environment. Java 21 is available, but the Android SDK is not configured and the Gradle wrapper distribution could not be downloaded because network DNS access is unavailable. Treat this as a source implementation, not a verified APK. Build with Android SDK Platform 36 and JDK 21, then test overlay permission, VPN permission, profile switching, Android 14+ foreground-service behavior, and HyperOS battery/background restrictions on the target phone.
