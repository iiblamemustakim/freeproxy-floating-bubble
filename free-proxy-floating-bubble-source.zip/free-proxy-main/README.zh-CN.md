# FreeProxy

[English](README.md) | 简体中文

把 HTTP / SOCKS5 代理转换成 Android 系统级 VPN 的客户端。

设备上所有（或指定）应用的流量会被 `VpnService` 捕获成 IP 包，在用户态还原成
TCP / UDP 会话，再经上游代理转发出去 —— 让本身不支持代理的应用也能走代理。

## 功能

- **配置管理**：多套 SOCKS5 / HTTP CONNECT 配置，支持用户名密码认证，可复制、编辑、删除，
  并可在保存前用真实握手做连通性检测
- **分应用代理**：三种模式 —— 全部应用 / 白名单（仅选中走代理）/ 黑名单（选中的绕过）
- **深色模式**：跟随系统、强制浅色、强制深色，另支持 Android 12+ 动态取色
- **通知栏状态**：常驻通知实时显示上下行流量，并提供一键断开
- **活动日志**：实时速率条 + 按事件着色的日志流，记录 DNS 查询与每条连接的结果，
  并标出是哪个应用发起的
- **DNS 解析模式**：每条配置可选让 DNS 走代理（隐私）或本地直连（速度）
- **平板与大屏**：窗口宽度达到 600dp 时自动切换为侧边导航，内容收窄居中，
  编辑页从全屏改为居中卡片
- 中英双语界面，开机自启，断网自动停止，绕过内网直连，IPv6 泄漏阻断

## 构建

环境要求：JDK 17+、Android SDK Platform 36。

```bash
./gradlew assembleDebug      # 调试包
./gradlew assembleRelease    # 发布包（已开启 R8）
./gradlew testDebugUnitTest  # 单元测试
```

产物在 `app/build/outputs/apk/`。

`local.properties` 里的 `sdk.dir` 已指向本机 SDK，换机器需要改。

## 实现说明

### 为什么是纯 Kotlin 的用户态协议栈

常见做法是集成 `tun2socks` 之类的 native 库，但那需要 NDK 工具链。本项目直接用
Kotlin 实现了一个精简的用户态 TCP/IP 栈，好处是无需 NDK、无 native 产物、单架构通吃。

核心简化：**写向 TUN 的数据是交给本机内核的，不经过任何有损链路**，因此不需要拥塞控制。
只要严格遵守对端宣告的接收窗口就不会丢包，超时重传只作为极端情况的兜底。
这让 `TcpSession` 的复杂度远低于一个完整 TCP 实现，同时在本地场景下依然可靠。

### 数据流

```
应用 → 系统路由 → TUN 设备
                    ↓  读线程
              Ipv4Header / TcpHeader / UdpHeader 解析
                    ↓
        TcpSession（用户态状态机）/ UdpSession
                    ↓  protect() 过的 socket
              ProxyClient（SOCKS5 握手 / HTTP CONNECT）
                    ↓
                上游代理 → 目标服务器
```

回程数据由 `PacketBuilder` 重新封装成 IP 包，经写队列送回 TUN。

### 几个关键处理

- **代理域名必须提前解析**：隧道一旦建立，DNS 查询会被路由进隧道，而隧道本身又依赖这次解析。
  因此 `FreeProxyVpnService` 在 `establish()` **之前**解析代理主机名，之后整个会话复用该地址。
- **绕过内网靠路由而非丢包**：`RouteCalculator` 从 `0.0.0.0/0` 中递归挖掉 RFC 1918 等网段，
  只把补集声明给 TUN，私有地址便继续走物理网卡。
- **DNS 自动降级**：代理不支持 UDP 时（HTTP 代理，或关闭了 UDP ASSOCIATE），
  DNS 查询会自动改用 DNS over TCP（RFC 7766）经代理完成，域名解析依然可用。
- **白名单为空时的退化**：Android 的 `addAllowedApplication` 一次都不调用等同于"全部放行"，
  含义容易误解，因此空白名单会退化为全局模式。
- **日志里的域名从哪来**：隧道里看到的目标只有 IP。`HostRegistry` 会顺路解析流经的 DNS 应答，
  建立 IP → 域名的反查表，连接日志因此能显示 `github.com:443` 而不是一串裸 IP。
- **日志里的应用归属**：靠 `ConnectivityManager.getConnectionOwnerUid` 反查四元组的属主 UID
  再映射到包名。该接口 Android 10 才有，更早的系统上这一列会留空。
- **大屏靠居中而不是算边距**：`ResponsiveContainer` 用居中对齐把内容收到 640dp 以内。
  一开始试过按屏幕宽度算左右边距，但侧边导航栏会占掉一块，算出来的边距会让内容整体偏向一侧。
  断点判断量的是 `LocalWindowInfo.containerSize` 而非屏幕尺寸，这样分屏和折叠屏才准确。

### 依赖取舍

没有引入 Hilt 和 Room：这个应用只有一个进程、两个仓库和一个常驻服务，
配置数据也只有几十条。用 DataStore 存 JSON + 手写依赖容器即可，
省掉整套注解处理器后构建更快、版本兼容问题也更少。

### 版本约束

工具链停在 **AGP 8.13.2 + compileSdk 36**。更高版本的 `androidx.core:core` (1.19+) 和
`androidx.lifecycle` (2.11+) 要求 AGP 9.1 / compileSdk 37，升级前需要先装 Android SDK Platform 37。

## 已知限制

| 限制 | 说明 |
|------|------|
| 不转发 IPv6 | 只做 IPv4。开启"阻断 IPv6"会把 IPv6 收进隧道丢弃，避免绕过代理泄漏 |
| 不支持 ICMP | 代理协议本身承载不了，隧道内 `ping` 不通属正常现象 |
| UDP 依赖代理能力 | 需要 SOCKS5 且支持 UDP ASSOCIATE；否则只有 DNS 能用（走 TCP） |
| 无窗口缩放 | 未协商 TCP Window Scaling，单连接吞吐受 64KB 窗口限制 |
| 不做分片重组 | 分片 IP 包会被丢弃；TUN 的 MTU 由本应用设定，正常流量不会分片 |
| 凭据明文存储 | 代理密码明文存于应用私有目录，已排除出云备份，但未做加密 |
| 应用归属需 Android 10+ | 日志里的应用识别依赖 `getConnectionOwnerUid`，更早系统上会留空 |

## 发布到 F-Droid

商店素材放在 `fastlane/metadata/android/{en-US,zh-CN}/`，F-Droid 会从本仓库自动抓取
描述、图标与截图；每次发新版需要新增 `changelogs/<versionCode>.txt`。
图标改动后跑 `art/render-icon.sh` 重新导出 512×512 的 `images/icon.png`。

上架流程：给版本打好 `vX.Y.Z` tag，把 `fdroid/tech.xvanturing.freeproxy.yml` 复制到
[fdroiddata](https://gitlab.com/fdroid/fdroiddata) 的 `metadata/` 下并开 merge request。
合并后由 F-Droid 的构建服务器从源码编译并用他们的 key 签名 —— 也就是说，
F-Droid 版与自行签名的 APK 互不兼容，不能直接覆盖升级。

## 测试

`app/src/test/` 下有 19 个单元测试，覆盖路由补集计算（含边界地址与重叠检查）、
IP/TCP/UDP 包的构造-解析往返、校验和自洽性、序列号回绕比较，
以及 DNS 报文解析（压缩指针、畸形报文、自指指针的死循环防御）。

完整链路需要真机验证：装上后添加一条代理配置，点连接，授予 VPN 权限即可。

## 许可证

[Apache License 2.0](LICENSE)。
