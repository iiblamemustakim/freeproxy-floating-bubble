package tech.xvanturing.freeproxy.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * 品牌色取自应用图标的隧道绿。
 * 未指定的槽位交给 Material 3 的默认推导，避免手工调色出现不协调的组合。
 */

private val Green40 = Color(0xFF10693F)
private val Green80 = Color(0xFF8BD6A6)
private val GreenContainerLight = Color(0xFFA6F2C0)
private val GreenContainerDark = Color(0xFF00522F)

private val Sage40 = Color(0xFF4E6355)
private val Sage80 = Color(0xFFB5CCBB)

private val Error40 = Color(0xFFBA1A1A)
private val Error80 = Color(0xFFFFB4AB)

val LightColors = lightColorScheme(
    primary = Green40,
    onPrimary = Color.White,
    primaryContainer = GreenContainerLight,
    onPrimaryContainer = Color(0xFF00210F),
    secondary = Sage40,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1E8D6),
    onSecondaryContainer = Color(0xFF0C1F14),
    tertiary = Color(0xFF3A6470),
    onTertiary = Color.White,
    error = Error40,
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF6FBF5),
    onBackground = Color(0xFF171D18),
    surface = Color(0xFFF6FBF5),
    onSurface = Color(0xFF171D18),
    surfaceVariant = Color(0xFFDCE5DC),
    onSurfaceVariant = Color(0xFF404942),
    outline = Color(0xFF707972),
    outlineVariant = Color(0xFFC0C9C0),
)

val DarkColors = darkColorScheme(
    primary = Green80,
    onPrimary = Color(0xFF00391F),
    primaryContainer = GreenContainerDark,
    onPrimaryContainer = GreenContainerLight,
    secondary = Sage80,
    onSecondary = Color(0xFF203528),
    secondaryContainer = Color(0xFF364B3E),
    onSecondaryContainer = Color(0xFFD1E8D6),
    tertiary = Color(0xFFA2CDDA),
    onTertiary = Color(0xFF023640),
    error = Error80,
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF0F1511),
    onBackground = Color(0xFFDFE4DE),
    surface = Color(0xFF0F1511),
    onSurface = Color(0xFFDFE4DE),
    surfaceVariant = Color(0xFF404942),
    onSurfaceVariant = Color(0xFFC0C9C0),
    outline = Color(0xFF8A938B),
    outlineVariant = Color(0xFF404942),
)

/** 连接状态用的语义色，不随动态取色改变，保证"绿=通、灰=断"始终一眼可辨。 */
val ConnectedGreen = Color(0xFF2E9E5B)
val ConnectingAmber = Color(0xFFE0A126)
val DisconnectedGrey = Color(0xFF8A938B)
