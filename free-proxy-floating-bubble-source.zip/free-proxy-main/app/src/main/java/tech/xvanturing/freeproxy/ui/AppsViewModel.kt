package tech.xvanturing.freeproxy.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import tech.xvanturing.freeproxy.AppContainer
import tech.xvanturing.freeproxy.data.AppListRepository
import tech.xvanturing.freeproxy.data.ProxyRepository
import tech.xvanturing.freeproxy.data.model.AppInfo
import tech.xvanturing.freeproxy.data.model.AppRoutingMode
import tech.xvanturing.freeproxy.data.model.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppsViewModel(
    private val repository: ProxyRepository,
    private val appListRepository: AppListRepository,
) : ViewModel() {

    private val _apps = MutableStateFlow<List<AppInfo>?>(null)

    /** null 表示仍在加载 —— 首次枚举安装包在设备上可能要一两秒。 */
    val apps: StateFlow<List<AppInfo>?> = _apps.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _showSystemApps = MutableStateFlow(false)
    val showSystemApps: StateFlow<Boolean> = _showSystemApps.asStateFlow()

    val settings: StateFlow<AppSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    init {
        viewModelScope.launch { _apps.value = appListRepository.loadApps() }
    }

    fun setQuery(value: String) {
        _query.value = value
    }

    fun setShowSystemApps(value: Boolean) {
        _showSystemApps.value = value
    }

    fun setMode(mode: AppRoutingMode) {
        viewModelScope.launch { repository.updateSettings { it.copy(routingMode = mode) } }
    }

    fun toggleApp(packageName: String) {
        viewModelScope.launch {
            repository.updateSettings { current ->
                val updated = current.selectedApps.toMutableSet()
                if (!updated.add(packageName)) updated.remove(packageName)
                current.copy(selectedApps = updated)
            }
        }
    }

    fun selectAll(packages: List<String>) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(selectedApps = it.selectedApps + packages) }
        }
    }

    fun clearSelection() {
        viewModelScope.launch { repository.updateSettings { it.copy(selectedApps = emptySet()) } }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                AppsViewModel(AppContainer.proxyRepository, AppContainer.appListRepository)
            }
        }
    }
}
