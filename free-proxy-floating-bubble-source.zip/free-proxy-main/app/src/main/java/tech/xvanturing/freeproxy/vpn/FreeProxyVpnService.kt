package tech.xvanturing.freeproxy.vpn

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import tech.xvanturing.freeproxy.AppContainer
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.data.model.AppRoutingMode
import tech.xvanturing.freeproxy.data.model.AppSettings
import tech.xvanturing.freeproxy.data.model.ProxyProfile
import tech.xvanturing.freeproxy.ui.MainActivity
import tech.xvanturing.freeproxy.vpn.dns.DnsBlocker
import tech.xvanturing.freeproxy.vpn.log.LogLevel
import tech.xvanturing.freeproxy.vpn.log.TunnelLog
import tech.xvanturing.freeproxy.vpn.net.RouteCalculator
import tech.xvanturing.freeproxy.vpn.proxy.SocketProtector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * 承载隧道的前台服务。
 *
 * 它负责三件事：按配置搭好 TUN 接口、把 [TunnelEngine] 跑起来、
 * 以及持续把状态反映到通知栏。
 */
class FreeProxyVpnService : VpnService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var engine: TunnelEngine? = null
    private var notificationJob: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private val underlyingNetworks = mutableSetOf<Network>()

    /** 串行化隧道的搭建与拆除，快速连续切换配置时不会交错。 */
    private val tunnelMutex = Mutex()

    /**
     * 委托给 [VpnService.protect]。
     * 用组合而不是让本类直接实现接口，避免与父类同名方法产生签名歧义。
     */
    private val protector = object : SocketProtector {
        override fun protect(socket: Socket): Boolean =
            this@FreeProxyVpnService.protect(socket)

        override fun protect(socket: DatagramSocket): Boolean =
            this@FreeProxyVpnService.protect(socket)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                return START_NOT_STICKY
            }
            ACTION_SWITCH -> {
                intent.getStringExtra(EXTRA_PROFILE_ID)?.let {
                    Log.i(TAG, "收到切换请求：$it（当前状态 ${VpnStateHolder.state.value.status}）")
                    switchTunnel(it)
                }
            }
            // intent 为 null 表示服务被系统重建，按上次配置重连
            else -> startTunnel()
        }
        return START_STICKY
    }

    override fun onRevoke() {
        Log.i(TAG, "VPN 权限被系统回收")
        stopTunnel()
    }

    override fun onDestroy() {
        stopTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ 启停

    private fun startTunnel() {
        serviceScope.launch {
            tunnelMutex.withLock {
                if (engine != null) return@withLock
                startTunnelLocked()
            }
        }
    }

    /** 调用方必须持有 [tunnelMutex]。 */
    private suspend fun startTunnelLocked() {
        val (profile, settings) = AppContainer.proxyRepository.snapshot()
        if (profile == null || profile.host.isBlank()) {
            failWith("未选择可用的代理配置")
            return
        }

        VpnStateHolder.onConnecting(profile.id, profile.name)
        TunnelLog.service("SERVICE_STARTED")
        enterForeground()

        // 关键：必须在 establish() 之前解析代理服务器域名。
        // 隧道一旦建立，DNS 查询就会被路由进隧道，而隧道又依赖这次解析，形成死锁。
        val proxyAddress = try {
            withContext(Dispatchers.IO) {
                InetSocketAddress(InetAddress.getByName(profile.host), profile.port)
            }
        } catch (e: Exception) {
            failWith("无法解析代理服务器地址：${profile.host}")
            return
        }

        val tunInterface = try {
            buildTunInterface(profile, settings)
        } catch (e: Exception) {
            failWith("建立 VPN 接口失败：${e.message}")
            return
        }

        engine = TunnelEngine(
            tunInterface = tunInterface,
            profile = profile,
            proxyAddress = proxyAddress,
            mtu = settings.mtu,
            protector = protector,
            appResolver = AppResolver(this@FreeProxyVpnService),
            dnsBlocker = DnsBlocker.fromSettings(settings),
        ).also { it.start() }

        VpnStateHolder.onConnected(SystemClock.elapsedRealtime())
        TunnelLog.service("PROXY_READY", LogLevel.SUCCESS)
        startNotificationUpdates()
        if (settings.stopOnNetworkLoss) watchUnderlyingNetwork()
        Log.i(TAG, "隧道已建立：${profile.summary}")
    }

    /**
     * 激活状态下热切换到另一个配置：拆掉旧隧道后用新配置原地重建。
     *
     * 不经过 stopForeground / stopSelf，通知栏保持前台不闪烁；
     * [startTunnelLocked] 里的 onConnecting 会直接把状态切到新配置的 CONNECTING。
     */
    private fun switchTunnel(profileId: String) {
        serviceScope.launch {
            tunnelMutex.withLock {
                // 未在运行（或刚被停掉）时忽略切换请求，避免把 VPN 拉起来
                if (engine == null && !VpnStateHolder.state.value.isActive) {
                    Log.i(TAG, "服务未在运行，忽略切换请求")
                    return@withLock
                }

                // 调用方保证写入落盘后才发切换请求；这里再核一遍，读到的仍是旧配置
                // （例如连点时被更新的请求覆盖）就放弃，避免把隧道重建回原来的配置
                val target = AppContainer.proxyRepository.activeProfile.first()
                if (target?.id != profileId) {
                    Log.w(TAG, "切换目标已过期（期望 $profileId，当前 ${target?.id}），取消切换")
                    return@withLock
                }

                TunnelLog.service("SWITCH_PROFILE: ${target.name}")
                teardownEngine()
                startTunnelLocked()

                // startTunnelLocked 失败会走 failWith，此时 engine 为空，不弹提示
                if (engine != null) {
                    val label = target.name.ifBlank { target.host }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@FreeProxyVpnService,
                            getString(R.string.profile_switched_toast, label),
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                }
            }
        }
    }

    private fun stopTunnel() {
        teardownEngine()
        if (VpnStateHolder.state.value.status != VpnStatus.ERROR) {
            VpnStateHolder.onDisconnected()
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /**
     * 停掉引擎及其附属任务，但不动前台状态、不 stopSelf。
     *
     * 保持同步：onRevoke / onDestroy 在主线程直接走 stopTunnel，
     * 而 onDestroy 随后会取消 serviceScope，异步拆除可能根本得不到执行。
     */
    private fun teardownEngine() {
        notificationJob?.cancel()
        notificationJob = null
        stopWatchingNetwork()
        val wasRunning = engine != null
        engine?.stop()
        engine = null
        if (wasRunning) TunnelLog.service("SERVICE_STOPPED")
    }

    private fun failWith(message: String) {
        Log.w(TAG, message)
        TunnelLog.service(message, LogLevel.FAILURE)
        VpnStateHolder.onError(message)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // -------------------------------------------------------- TUN 配置

    private fun buildTunInterface(
        profile: ProxyProfile,
        settings: AppSettings,
    ): ParcelFileDescriptor {
        val builder = Builder()
            .setSession(profile.name)
            .setMtu(settings.mtu)
            .addAddress(TUN_ADDRESS, TUN_PREFIX)
            .addDnsServer(settings.dnsServer)
            .setConfigureIntent(
                PendingIntent.getActivity(
                    this,
                    0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                ),
            )

        // 阻塞模式下 read() 才会等待数据；否则读线程会空转跑满 CPU
        builder.setBlocking(true)

        val routes = if (settings.bypassLan) RouteCalculator.BYPASS_PRIVATE else RouteCalculator.DEFAULT
        routes.forEach { builder.addRoute(it.addressLiteral, it.prefixLength) }

        // 本栈只处理 IPv4。把 IPv6 也收进隧道然后丢弃，避免流量绕过代理泄漏出去。
        if (settings.enableIpv6) {
            runCatching {
                builder.addAddress(TUN_ADDRESS_V6, TUN_PREFIX_V6)
                builder.addRoute("::", 0)
            }
        }

        applyPerAppRules(builder, settings)

        return builder.establish() ?: error("系统拒绝建立 VPN 接口")
    }

    /**
     * 落实分应用代理规则。
     *
     * 注意 addAllowedApplication 与 addDisallowedApplication 不能混用，
     * 因此白名单模式下不再单独排除自身 —— 本应用不在白名单里，自然就走不到隧道。
     */
    private fun applyPerAppRules(builder: Builder, settings: AppSettings) {
        val self = packageName
        val selected = settings.selectedApps.filterNot { it == self }

        when (settings.routingMode) {
            AppRoutingMode.ALL -> builder.excludeQuietly(self)

            AppRoutingMode.ALLOW -> {
                if (selected.isEmpty()) {
                    // 空白名单在系统层面等同于"全部放行"，含义容易误解，退化为全局模式
                    builder.excludeQuietly(self)
                } else {
                    selected.forEach { pkg ->
                        runCatching { builder.addAllowedApplication(pkg) }
                            .onFailure { Log.w(TAG, "白名单跳过已卸载的应用：$pkg") }
                    }
                }
            }

            AppRoutingMode.DISALLOW -> {
                builder.excludeQuietly(self)
                selected.forEach { builder.excludeQuietly(it) }
            }
        }
    }

    /** 应用可能已被卸载，addDisallowedApplication 会抛 NameNotFoundException。 */
    private fun Builder.excludeQuietly(packageName: String) {
        runCatching { addDisallowedApplication(packageName) }
            .onFailure { Log.w(TAG, "黑名单跳过已卸载的应用：$packageName") }
    }

    // ------------------------------------------------------- 网络监听

    /**
     * 盯住底层（非 VPN）网络。
     *
     * 请求里带上 NOT_VPN，否则我们自己建立的隧道也会被算作一条可用网络，
     * 那样就永远等不到"全部断开"。
     */
    private fun watchUnderlyingNetwork() {
        val manager = getSystemService<ConnectivityManager>() ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                synchronized(underlyingNetworks) { underlyingNetworks += network }
            }

            override fun onLost(network: Network) {
                val allGone = synchronized(underlyingNetworks) {
                    underlyingNetworks -= network
                    underlyingNetworks.isEmpty()
                }
                if (allGone) {
                    Log.i(TAG, "底层网络已断开，按设置停止隧道")
                    TunnelLog.service("NETWORK_LOST", LogLevel.FAILURE)
                    stopTunnel()
                }
            }
        }

        runCatching { manager.registerNetworkCallback(request, callback) }
            .onSuccess { networkCallback = callback }
            .onFailure { Log.w(TAG, "无法监听网络变化：${it.message}") }
    }

    private fun stopWatchingNetwork() {
        val callback = networkCallback ?: return
        networkCallback = null
        synchronized(underlyingNetworks) { underlyingNetworks.clear() }
        runCatching {
            getSystemService<ConnectivityManager>()?.unregisterNetworkCallback(callback)
        }
    }

    // ----------------------------------------------------------- 通知

    private fun enterForeground() {
        VpnNotifications.ensureChannel(this)
        val notification = VpnNotifications.build(this, VpnStateHolder.state.value)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, VpnNotifications.NOTIFICATION_ID, notification, type)
    }

    private fun startNotificationUpdates() {
        notificationJob?.cancel()
        notificationJob = serviceScope.launch {
            val manager = getSystemService<NotificationManager>()
            while (isActive) {
                delay(NOTIFICATION_INTERVAL_MS)
                VpnStateHolder.publishCounters()
                val state = VpnStateHolder.state.value
                if (!state.isActive) break
                if (NotificationManagerCompat.from(this@FreeProxyVpnService).areNotificationsEnabled()) {
                    manager?.notify(
                        VpnNotifications.NOTIFICATION_ID,
                        VpnNotifications.build(this@FreeProxyVpnService, state),
                    )
                }
            }
        }
    }

    companion object {
        private const val TAG = "FreeProxyVpn"

        const val ACTION_START = "tech.xvanturing.freeproxy.action.START"
        const val ACTION_STOP = "tech.xvanturing.freeproxy.action.STOP"
        const val ACTION_SWITCH = "tech.xvanturing.freeproxy.action.SWITCH"
        const val EXTRA_PROFILE_ID = "tech.xvanturing.freeproxy.extra.PROFILE_ID"

        /** 隧道内的私有地址，选一个不常见的网段以免和本地网络撞车。 */
        private const val TUN_ADDRESS = "10.215.173.1"
        private const val TUN_PREFIX = 24
        private const val TUN_ADDRESS_V6 = "fd00:1:fd00:1:fd00:1:fd00:1"
        private const val TUN_PREFIX_V6 = 64
        private const val NOTIFICATION_INTERVAL_MS = 2_000L

        fun start(context: Context) {
            val intent = Intent(context, FreeProxyVpnService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, FreeProxyVpnService::class.java).setAction(ACTION_STOP)
            context.startService(intent)
        }

        /** 服务激活时请求热切换到 [profileId]；服务未运行时该请求会被忽略。 */
        fun switchProfile(context: Context, profileId: String) {
            val intent = Intent(context, FreeProxyVpnService::class.java)
                .setAction(ACTION_SWITCH)
                .putExtra(EXTRA_PROFILE_ID, profileId)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
