package tech.xvanturing.freeproxy.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * 布局断点。
 *
 * 600dp 是 Material 3 的 compact/medium 分界：手机竖屏在下面，平板与横屏在上面。
 */
object Breakpoints {
    val MEDIUM: Dp = 600.dp

    /** 单列内容的舒适上限；再宽下去一行字太长，反而难读。 */
    val ContentMaxWidth: Dp = 640.dp
}

/**
 * 判断当前是否为宽布局。
 *
 * 量的是窗口容器而不是物理屏幕 —— 分屏、自由窗口、折叠屏展开这些情况下，
 * 应用拿到的宽度和屏幕宽度并不是一回事。
 */
@Composable
@ReadOnlyComposable
fun isWideLayout(): Boolean {
    val containerWidth = LocalWindowInfo.current.containerSize.width
    return with(LocalDensity.current) { containerWidth.toDp() } >= Breakpoints.MEDIUM
}

/**
 * 把内容收窄到可读宽度并居中。
 *
 * 用居中对齐而不是计算左右边距 —— 侧边导航栏会占掉一部分屏幕，
 * 按屏幕总宽度算出来的边距会让内容整体偏向一侧。
 */
@Composable
fun ResponsiveContainer(
    modifier: Modifier = Modifier,
    maxWidth: Dp = Breakpoints.ContentMaxWidth,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Box(modifier = Modifier.widthIn(max = maxWidth).fillMaxSize()) {
            content()
        }
    }
}

/** 只约束宽度、不铺满高度的版本，适合放在可滚动列表之外的位置。 */
@Composable
fun ResponsiveRow(
    modifier: Modifier = Modifier,
    maxWidth: Dp = Breakpoints.ContentMaxWidth,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Box(modifier = Modifier.widthIn(max = maxWidth).fillMaxWidth()) {
            content()
        }
    }
}
