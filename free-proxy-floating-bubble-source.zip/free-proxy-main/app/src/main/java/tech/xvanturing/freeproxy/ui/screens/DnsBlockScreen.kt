package tech.xvanturing.freeproxy.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.data.model.AppInfo
import tech.xvanturing.freeproxy.ui.AppsViewModel
import tech.xvanturing.freeproxy.ui.MainViewModel
import tech.xvanturing.freeproxy.ui.components.AppIcon
import tech.xvanturing.freeproxy.ui.components.FreeProxyTextField
import tech.xvanturing.freeproxy.ui.components.ResponsiveContainer
import tech.xvanturing.freeproxy.ui.components.SettingRow
import tech.xvanturing.freeproxy.ui.components.SwitchRow
import tech.xvanturing.freeproxy.ui.components.rememberAppLabel

/**
 * DNS 拦截：按应用全量拦截，或按域名名单拦截，命中即伪造应答。
 *
 * 头部是总开关与伪造应答 IP，下面用 Tab 分成「域名」和「应用」两页。
 * 应用列表复用 [AppsViewModel] 的加载与搜索，选中状态则写在
 * [MainViewModel] 的 dnsBlockApps 上 —— 与分应用代理的名单互不相干。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DnsBlockScreen(
    viewModel: MainViewModel,
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    appsViewModel: AppsViewModel = viewModel(factory = AppsViewModel.Factory),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var showIpDialog by remember { mutableStateOf(false) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    ResponsiveContainer {
    Column(modifier = Modifier.fillMaxSize()) {
    TopAppBar(
        title = { Text(stringResource(R.string.dns_block_title)) },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
            }
        },
    )
    SwitchRow(
        title = stringResource(R.string.dns_block_enable),
        subtitle = stringResource(R.string.dns_block_enable_desc),
        checked = settings.dnsBlockEnabled,
        onCheckedChange = viewModel::setDnsBlockEnabled,
    )
    SettingRow(
        title = stringResource(R.string.dns_block_response_ip),
        subtitle = settings.dnsBlockResponseIp,
        onClick = { showIpDialog = true },
    )
    Text(
        text = stringResource(R.string.dns_block_restart_hint),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
    )

    TabRow(selectedTabIndex = selectedTab) {
        Tab(
            selected = selectedTab == TAB_DOMAINS,
            onClick = { selectedTab = TAB_DOMAINS },
            text = { Text(stringResource(R.string.dns_block_domains)) },
        )
        Tab(
            selected = selectedTab == TAB_APPS,
            onClick = { selectedTab = TAB_APPS },
            text = { Text(stringResource(R.string.dns_block_apps)) },
        )
    }

    val listPadding = PaddingValues(
        top = 8.dp,
        bottom = contentPadding.calculateBottomPadding() + 24.dp,
    )
    when (selectedTab) {
        TAB_DOMAINS -> DnsBlockDomainsTab(
            domains = settings.dnsBlockDomains,
            sources = settings.dnsBlockDomainSources,
            onAdd = { viewModel.addDnsBlockDomains(it) },
            onRemove = viewModel::removeDnsBlockDomain,
            contentPadding = listPadding,
        )
        else -> DnsBlockAppsTab(
            blockedApps = settings.dnsBlockApps,
            onToggleApp = viewModel::toggleDnsBlockApp,
            appsViewModel = appsViewModel,
            contentPadding = listPadding,
        )    }
    }
    }

    if (showIpDialog) {
        ResponseIpDialog(
            initial = settings.dnsBlockResponseIp,
            onConfirm = { value ->
                viewModel.setDnsBlockResponseIp(value)
                showIpDialog = false
            },
            onDismiss = { showIpDialog = false },
        )
    }
}

private const val TAB_DOMAINS = 0
private const val TAB_APPS = 1

/** 域名名单：逐条添加、文件导入、删除；从日志添加的规则展示来源应用。 */
@Composable
private fun DnsBlockDomainsTab(
    domains: Set<String>,
    sources: Map<String, String>,
    onAdd: (List<String>) -> Unit,
    onRemove: (String) -> Unit,
    contentPadding: PaddingValues,
) {
    val context = LocalContext.current
    var domainInput by remember { mutableStateOf("") }

    // 域名文件一行一条；# 与 ! 开头视为注释（兼容常见 hosts/广告名单格式）
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            val imported = runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    input.bufferedReader().lineSequence()
                        .map { it.trim() }
                        .filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("!") }
                        .toList()
                }.orEmpty()
            }
            imported.onSuccess { domains ->
                onAdd(domains)
                Toast.makeText(
                    context,
                    context.getString(R.string.dns_block_import_success, domains.size),
                    Toast.LENGTH_SHORT,
                ).show()
            }.onFailure {
                Toast.makeText(context, R.string.dns_block_import_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = contentPadding) {
        item {
            Text(
                text = stringResource(R.string.dns_block_domains_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FreeProxyTextField(
                    value = domainInput,
                    onValueChange = { domainInput = it },
                    placeholder = { Text(stringResource(R.string.dns_block_domain_input)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.weight(1f),
                )
                IconButton(
                    onClick = {
                        onAdd(listOf(domainInput))
                        domainInput = ""
                    },
                    enabled = domainInput.isNotBlank(),
                ) {
                    Icon(
                        Icons.Rounded.Add,
                        contentDescription = stringResource(R.string.dns_block_domain_add),
                    )
                }
            }
            Row(modifier = Modifier.padding(horizontal = 16.dp)) {
                TextButton(
                    onClick = { importLauncher.launch(arrayOf("text/plain", "*/*")) },
                ) {
                    Text(stringResource(R.string.dns_block_import))
                }
            }
        }

        if (domains.isEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.dns_block_domain_empty),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        } else {
            items(domains.sorted(), key = { it }) { domain ->
                val sourcePackage = sources[domain]
                SettingRow(
                    title = domain,
                    subtitle = sourcePackage?.let {
                        stringResource(R.string.dns_block_domain_source, rememberAppLabel(it))
                    },
                    trailing = {
                        IconButton(onClick = { onRemove(domain) }) {
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = stringResource(R.string.delete),
                            )
                        }
                    },
                )
            }
        }
    }
}

/** 应用名单：搜索、系统应用开关、多选。 */
@Composable
private fun DnsBlockAppsTab(
    blockedApps: Set<String>,
    onToggleApp: (String) -> Unit,
    appsViewModel: AppsViewModel,
    contentPadding: PaddingValues,
) {
    val apps by appsViewModel.apps.collectAsStateWithLifecycle()
    val query by appsViewModel.query.collectAsStateWithLifecycle()
    val showSystemApps by appsViewModel.showSystemApps.collectAsStateWithLifecycle()
    var onlySelected by rememberSaveable { mutableStateOf(false) }

    // 已选的应用始终排在前面，方便在长列表里直接看到
    val visibleApps = remember(apps, query, showSystemApps, blockedApps, onlySelected) {
        var list = apps.orEmpty()
        if (!showSystemApps) list = list.filterNot { it.isSystem }
        if (query.isNotBlank()) {
            val needle = query.trim().lowercase()
            list = list.filter {
                it.label.lowercase().contains(needle) || it.packageName.lowercase().contains(needle)
            }
        }
        if (onlySelected) list = list.filter { it.packageName in blockedApps }
        list.sortedByDescending { it.packageName in blockedApps }
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = contentPadding) {
        item {
            Text(
                text = stringResource(R.string.dns_block_apps_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            SwitchRow(
                title = stringResource(R.string.apps_show_system),
                checked = showSystemApps,
                onCheckedChange = appsViewModel::setShowSystemApps,
            )
            FreeProxyTextField(
                value = query,
                onValueChange = appsViewModel::setQuery,
                placeholder = { Text(stringResource(R.string.apps_search)) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = pluralStringResource(
                        R.plurals.dns_block_apps_selected,
                        blockedApps.size,
                        blockedApps.size,
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                )
                FilterChip(
                    selected = onlySelected,
                    onClick = { onlySelected = !onlySelected },
                    label = { Text(stringResource(R.string.dns_block_apps_only_selected)) },
                )
            }
        }

        if (apps == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }
        } else {
            items(visibleApps, key = { it.packageName }) { app ->
                DnsBlockAppRow(
                    app = app,
                    checked = app.packageName in blockedApps,
                    onToggle = { onToggleApp(app.packageName) },
                )
            }
        }
    }
}

@Composable
private fun DnsBlockAppRow(
    app: AppInfo,
    checked: Boolean,
    onToggle: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(packageName = app.packageName, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = app.label, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = app.packageName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun ResponseIpDialog(
    initial: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    val valid = isValidIpv4(text.trim())
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.dns_block_response_ip)) },
        text = {
            FreeProxyTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                isError = !valid,
                supportingText = {
                    if (!valid) Text(stringResource(R.string.dns_block_invalid_ip))
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(text.trim()) },
                enabled = valid,
            ) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

private fun isValidIpv4(value: String): Boolean {
    val parts = value.split('.')
    return parts.size == 4 && parts.all { it.toIntOrNull() in 0..255 }
}
