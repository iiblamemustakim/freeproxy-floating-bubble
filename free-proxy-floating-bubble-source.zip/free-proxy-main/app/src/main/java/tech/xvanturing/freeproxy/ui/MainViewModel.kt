package tech.xvanturing.freeproxy.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import tech.xvanturing.freeproxy.AppContainer
import tech.xvanturing.freeproxy.data.ProxyRepository
import tech.xvanturing.freeproxy.data.model.AppSettings
import tech.xvanturing.freeproxy.data.model.ProxyProfile
import tech.xvanturing.freeproxy.data.model.ThemeMode
import tech.xvanturing.freeproxy.vpn.VpnStateHolder
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(private val repository: ProxyRepository) : ViewModel() {

    val profiles: StateFlow<List<ProxyProfile>> = repository.profiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), emptyList())

    val activeProfile: StateFlow<ProxyProfile?> = repository.activeProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), null)

    val settings: StateFlow<AppSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), AppSettings())

    val vpnState = VpnStateHolder.state

    fun newProfileId(): String = repository.newProfileId()

    fun saveProfile(profile: ProxyProfile) {
        viewModelScope.launch { repository.upsertProfile(profile) }
    }

    fun deleteProfile(id: String) {
        viewModelScope.launch { repository.deleteProfile(id) }
    }

    /**
     * 选中配置。[onCommitted] 在写入落盘后触发 —— 需要通知运行中的服务热切换时，
     * 必须等落盘完成再发请求，否则服务侧可能读到旧配置。
     */
    fun selectProfile(id: String, onCommitted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.setActiveProfile(id)
            onCommitted()
        }
    }

    fun duplicateProfile(profile: ProxyProfile) {
        viewModelScope.launch {
            repository.upsertProfile(
                profile.copy(id = repository.newProfileId(), name = "${profile.name} (2)"),
            )
        }
    }

    fun setThemeMode(mode: ThemeMode) = update { it.copy(themeMode = mode) }

    fun setDynamicColor(enabled: Boolean) = update { it.copy(dynamicColor = enabled) }

    fun setDnsServer(value: String) = update { it.copy(dnsServer = value) }

    fun setMtu(value: Int) = update { it.copy(mtu = value.coerceIn(576, 9000)) }

    fun setEnableIpv6(enabled: Boolean) = update { it.copy(enableIpv6 = enabled) }

    fun setBypassLan(enabled: Boolean) = update { it.copy(bypassLan = enabled) }

    fun setAutoStart(enabled: Boolean) = update { it.copy(autoStart = enabled) }

    fun setFloatingBubbleEnabled(enabled: Boolean) = update { it.copy(floatingBubbleEnabled = enabled) }

    fun setStopOnNetworkLoss(enabled: Boolean) = update { it.copy(stopOnNetworkLoss = enabled) }

    fun setDnsBlockEnabled(enabled: Boolean) = update { it.copy(dnsBlockEnabled = enabled) }

    fun setDnsBlockResponseIp(value: String) = update { it.copy(dnsBlockResponseIp = value) }

    fun toggleDnsBlockApp(packageName: String) = update { current ->
        val updated = current.dnsBlockApps.toMutableSet()
        if (!updated.add(packageName)) updated.remove(packageName)
        current.copy(dnsBlockApps = updated)
    }

    /**
     * 添加域名规则；导入与手动添加共用，重复项由集合语义自动去掉。
     *
     * @param sourcePackage 从日志添加时记录来源应用的包名，仅作展示，不影响匹配。
     */
    fun addDnsBlockDomains(domains: Collection<String>, sourcePackage: String? = null) = update { current ->
        val normalized = domains.mapNotNull { normalizeDomain(it) }
        val sources = if (sourcePackage == null || normalized.isEmpty()) {
            current.dnsBlockDomainSources
        } else {
            current.dnsBlockDomainSources + normalized.associateWith { sourcePackage }
        }
        current.copy(
            dnsBlockDomains = current.dnsBlockDomains + normalized,
            dnsBlockDomainSources = sources,
        )
    }

    fun removeDnsBlockDomain(domain: String) = update { current ->
        current.copy(
            dnsBlockDomains = current.dnsBlockDomains - domain,
            dnsBlockDomainSources = current.dnsBlockDomainSources - domain,
        )
    }

    fun resetSettings() = update {
        // 外观偏好与拦截名单属于个人积累，重置网络参数时不要一并抹掉
        AppSettings(
            themeMode = it.themeMode,
            dynamicColor = it.dynamicColor,
            routingMode = it.routingMode,
            selectedApps = it.selectedApps,
            dnsBlockEnabled = it.dnsBlockEnabled,
            dnsBlockApps = it.dnsBlockApps,
            dnsBlockDomains = it.dnsBlockDomains,
            dnsBlockDomainSources = it.dnsBlockDomainSources,
            dnsBlockResponseIp = it.dnsBlockResponseIp,
            floatingBubbleEnabled = it.floatingBubbleEnabled,
        )
    }

    /** 与 [tech.xvanturing.freeproxy.vpn.dns.DnsBlocker] 的规范化保持一致：小写、去根点。 */
    private fun normalizeDomain(raw: String): String? =
        raw.trim().lowercase().removeSuffix(".").ifEmpty { null }

    private fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { repository.updateSettings(transform) }
    }

    companion object {
        private const val STOP_TIMEOUT = 5_000L

        val Factory = viewModelFactory {
            initializer { MainViewModel(AppContainer.proxyRepository) }
        }
    }
}
