package tech.xvanturing.freeproxy.data.model

import kotlinx.serialization.Serializable

/** 上游代理协议。 */
@Serializable
enum class ProxyType {
    SOCKS5,
    HTTP,
    ;

    val displayName: String
        get() = when (this) {
            SOCKS5 -> "SOCKS5"
            HTTP -> "HTTP CONNECT"
        }
}

/** DNS 查询的走向。 */
@Serializable
enum class DnsMode {
    /** 经代理解析：隐私更好，代理看得到你查了什么，本地网络看不到。 */
    PROXY,

    /** 本地直连解析：更快，但查询对所在网络可见。 */
    DIRECT,
}

/** 一条代理配置。密码以明文存放在应用私有目录，并已排除出云备份。 */
@Serializable
data class ProxyProfile(
    val id: String,
    val name: String,
    val type: ProxyType = ProxyType.SOCKS5,
    val host: String = "",
    val port: Int = 1080,
    val username: String = "",
    val password: String = "",
    /** 仅 SOCKS5 有效：是否用 UDP ASSOCIATE 转发 UDP。 */
    val udpOverSocks: Boolean = true,
    val dnsMode: DnsMode = DnsMode.PROXY,
) {
    val requiresAuth: Boolean get() = username.isNotEmpty()

    val summary: String get() = "${type.displayName}  ·  $host:$port"
}

/** 分应用代理模式。 */
@Serializable
enum class AppRoutingMode {
    /** 所有应用都进入隧道。 */
    ALL,

    /** 仅名单内的应用进入隧道（VpnService.addAllowedApplication）。 */
    ALLOW,

    /** 名单内的应用绕过隧道（VpnService.addDisallowedApplication）。 */
    DISALLOW,
}

/** 主题模式。 */
@Serializable
enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
}

/** 全局设置。 */
@Serializable
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val dnsServer: String = "1.1.1.1",
    val mtu: Int = 1500,
    val enableIpv6: Boolean = false,
    val bypassLan: Boolean = true,
    val autoStart: Boolean = false,
    /** 底层网络断开时自动停止隧道，避免连接长时间挂死。 */
    val stopOnNetworkLoss: Boolean = false,
    val routingMode: AppRoutingMode = AppRoutingMode.ALL,
    /** 参与分应用规则的包名集合，含义随 [routingMode] 变化。 */
    val selectedApps: Set<String> = emptySet(),
    /** DNS 拦截总开关：命中规则的查询直接由隧道伪造应答，不再转发。 */
    val dnsBlockEnabled: Boolean = false,
    /** 这些应用的全部 DNS 查询都被拦截（包名集合）。 */
    val dnsBlockApps: Set<String> = emptySet(),
    /** 域名拦截名单：example.com 含其子域，*.example.com 仅子域。 */
    val dnsBlockDomains: Set<String> = emptySet(),
    /** 域名规则的来源应用（规范化域名 → 包名）：从日志添加时记录，手动/导入添加无来源。 */
    val dnsBlockDomainSources: Map<String, String> = emptyMap(),
    /** 伪造应答返回的 IPv4 地址。 */
    val dnsBlockResponseIp: String = "127.0.0.1",
    /** Keep a draggable overlay bubble available outside the main activity. */
    val floatingBubbleEnabled: Boolean = false,
)

/** 应用列表条目（运行时从 PackageManager 读取，不做持久化）。 */
data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
)
