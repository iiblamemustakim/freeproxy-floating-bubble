package tech.xvanturing.freeproxy.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.EnterExitState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.ui.components.isWideLayout
import tech.xvanturing.freeproxy.ui.screens.AppsScreen
import tech.xvanturing.freeproxy.ui.screens.DnsBlockScreen
import tech.xvanturing.freeproxy.ui.screens.HomeScreen
import tech.xvanturing.freeproxy.ui.screens.LoggingScreen
import tech.xvanturing.freeproxy.ui.screens.ProfilesScreen
import tech.xvanturing.freeproxy.ui.screens.SettingsScreen
import tech.xvanturing.freeproxy.vpn.FreeProxyVpnService

/** 底部导航的四个主目的地。 */
private enum class Destination(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector,
) {
    HOME("home", R.string.nav_home, Icons.Rounded.Shield),
    PROFILES("profiles", R.string.nav_configs, Icons.Rounded.Dns),
    LOGGING("logging", R.string.nav_logging, Icons.Rounded.Analytics),
    SETTINGS("settings", R.string.nav_settings, Icons.Rounded.Settings),
}

/** 分应用代理是低频配置，做成设置里的二级页面而不占用底部导航。 */
private const val ROUTE_PER_APP = "per-app"

/** DNS 拦截同理：拦截规则、应用名单都放在二级页面。 */
private const val ROUTE_DNS_BLOCK = "dns-blocking"

@Composable
fun FreeProxyRoot(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    // 系统的 VPN 授权对话框：同意后才能建立隧道
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            FreeProxyVpnService.start(context)
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* 拒绝也不影响连通性，只是通知栏不显示状态 */ }

    val onToggleConnection: (Boolean) -> Unit = { isActive ->
        if (isActive) {
            FreeProxyVpnService.stop(context)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent == null) {
                FreeProxyVpnService.start(context)
            } else {
                vpnPermissionLauncher.launch(prepareIntent)
            }
        }
    }

    val wideLayout = isWideLayout()

    val navigateTo: (Destination) -> Unit = { destination ->
        navController.navigate(destination.route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    val isSelected: (Destination) -> Boolean = { destination ->
        currentRoute?.hierarchy?.any { it.route == destination.route } == true
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        // 宽屏改用侧边导航栏，底部栏在横屏平板上既浪费高度也不合规范
        bottomBar = {
            if (!wideLayout) {
                NavigationBar {
                    Destination.entries.forEach { destination ->
                        NavigationBarItem(
                            selected = isSelected(destination),
                            onClick = { navigateTo(destination) },
                            icon = { Icon(destination.icon, contentDescription = null) },
                            label = { Text(stringResource(destination.labelRes)) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        Row(modifier = Modifier.fillMaxSize()) {
            if (wideLayout) {
                NavigationRail(
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(top = padding.calculateTopPadding()),
                ) {
                    Spacer(Modifier.weight(1f))
                    Destination.entries.forEach { destination ->
                        NavigationRailItem(
                            selected = isSelected(destination),
                            onClick = { navigateTo(destination) },
                            icon = { Icon(destination.icon, contentDescription = null) },
                            label = { Text(stringResource(destination.labelRes)) },
                        )
                    }
                    Spacer(Modifier.weight(1f))
                }
            }
            NavHost(
                navController = navController,
                startDestination = Destination.HOME.route,
                modifier = Modifier.fillMaxSize(),
            ) {
                composable(Destination.HOME.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        contentPadding = padding,
                        onToggleConnection = onToggleConnection,
                        // 走和底部导航同一套栈管理：配置页是平级目的地，不能压在首页上面，
                        // 否则它落在 tab 的 saveState/restoreState 之外，点回“首页”会没反应
                        onNavigateToProfiles = { navigateTo(Destination.PROFILES) },
                        // 转场期间正在退出的页面仍盖在上层并能收到点击，
                        // 必须禁用它的 FAB，否则快速点击会落在淡出中的“残影”上
                        fabEnabled = transition.targetState == EnterExitState.Visible,
                    )
                }
                composable(Destination.PROFILES.route) {
                    ProfilesScreen(
                        viewModel = viewModel,
                        contentPadding = padding,
                        fabEnabled = transition.targetState == EnterExitState.Visible,
                    )
                }
                composable(Destination.LOGGING.route) {
                    LoggingScreen(viewModel = viewModel, contentPadding = padding)
                }
                composable(Destination.SETTINGS.route) {
                    SettingsScreen(
                        viewModel = viewModel,
                        contentPadding = padding,
                        onOpenPerAppProxy = {
                            navController.navigate(ROUTE_PER_APP) { launchSingleTop = true }
                        },
                        onOpenDnsBlock = {
                            navController.navigate(ROUTE_DNS_BLOCK) { launchSingleTop = true }
                        },
                    )
                }
                composable(ROUTE_PER_APP) {
                    AppsScreen(
                        contentPadding = padding,
                        onBack = { navController.popBackStack() },
                    )
                }
                composable(ROUTE_DNS_BLOCK) {
                    DnsBlockScreen(
                        viewModel = viewModel,
                        contentPadding = padding,
                        onBack = { navController.popBackStack() },
                    )
                }
            }
        }
    }
}
