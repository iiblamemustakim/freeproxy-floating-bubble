package tech.xvanturing.freeproxy.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import tech.xvanturing.freeproxy.AppContainer
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.ui.MainActivity

/** Persistent overlay controller. It delegates all VPN work to FreeProxyVpnService. */
class FloatingBubbleService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var menu: PopupWindow? = null
    private var code: String? = null
    private var connected = false
    private val prefs by lazy { getSharedPreferences("floating_bubble", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        createChannel()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7401, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7401, notification())
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createBubble()
        scope.launch {
            combine(VpnStateHolder.state, AppContainer.proxyRepository.profiles) { state, profiles ->
                // Resolve exactly the profile ID reported by the live tunnel. Usernames from
                // every other saved profile are never inspected or parsed.
                val liveProfile = if (state.status == VpnStatus.CONNECTED || state.status == VpnStatus.CONNECTING) {
                    profiles.firstOrNull { it.id == state.profileId }
                } else null
                Triple(state.status == VpnStatus.CONNECTED, liveProfile?.username?.let(CountryCode::fromUsername), state.status)
            }.collectLatest { (isConnected, activeCode, _) ->
                connected = isConnected
                code = activeCode
                render()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) stopSelf()
        return START_STICKY
    }

    private fun createBubble() {
        val size = prefs.getInt("size", 64).coerceIn(48, 100)
        val alpha = prefs.getInt("opacity", 90).coerceIn(20, 100) / 100f
        val pxSize = (size * resources.displayMetrics.density).toInt()
        val view = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            this.alpha = alpha
            setOnClickListener { toggleConnection() }
            setOnLongClickListener { showMenu(); true }
            setOnTouchListener(DragTouchListener())
        }
        val lp = WindowManager.LayoutParams(pxSize, pxSize, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 24); y = prefs.getInt("y", 220)
        }
        bubble = view; params = lp
        wm.addView(view, lp)
        render()
    }

    private fun render() {
        val view = bubble ?: return
        val active = connected
        val countryFlag = if (active) CountryCode.flag(code) else "●"
        val short = when {
            active && code != null -> "\n$code"
            active -> "\n??"
            else -> "\nOFF"
        }
        view.text = countryFlag + short
        view.contentDescription = if (active) "Connected ${code ?: "unknown country"}" else "Disconnected"
        view.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (active) 0xCC167D4A.toInt() else 0xCC444444.toInt())
        }
    }

    private fun toggleConnection() {
        if (connected || VpnStateHolder.state.value.status == VpnStatus.CONNECTING) FreeProxyVpnService.stop(this)
        else FreeProxyVpnService.start(this)
    }

    private fun showMenu() {
        menu?.dismiss()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); setBackgroundColor(0xFF202124.toInt()) }
        fun action(label: String, run: () -> Unit) {
            panel.addView(Button(this).apply { text = label; setOnClickListener { menu?.dismiss(); run() } })
        }
        action(if (connected) "Disconnect" else "Connect") { toggleConnection() }
        action("Resize bubble") {
            val next = when (prefs.getInt("size", 64)) { in 0..56 -> 72; in 57..76 -> 92; else -> 52 }
            prefs.edit().putInt("size", next).apply(); recreateBubble()
        }
        panel.addView(TextView(this).apply { text = "Opacity"; setTextColor(0xFFFFFFFF.toInt()); setPadding(8, 10, 8, 2) })
        panel.addView(SeekBar(this).apply {
            max = 80
            progress = (prefs.getInt("opacity", 90).coerceIn(20, 100) - 20)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 20
                    prefs.edit().putInt("opacity", value).apply()
                    bubble?.alpha = value / 100f
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        })
        action("Settings") { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        action("Close popup") {
            scope.launch {
                AppContainer.proxyRepository.updateSettings { it.copy(floatingBubbleEnabled = false) }
                stopSelf()
            }
        }
        menu = PopupWindow(panel, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true
            showAtLocation(bubble, Gravity.CENTER, 0, 0)
        }
    }

    private fun recreateBubble() {
        val old = bubble ?: return
        val oldParams = params
        runCatching { wm.removeView(old) }
        bubble = null
        createBubble()
        if (oldParams != null) { params?.x = oldParams.x; params?.y = oldParams.y }
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0; private var startY = 0; private var downX = 0f; private var downY = 0f
        private var moved = false
        private var downAt = 0L
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val lp = params ?: return false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = lp.x; startY = lp.y; downX = e.rawX; downY = e.rawY; downAt = e.eventTime; moved = false; return true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                    if (moved) { lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(v, lp) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    else if (e.eventTime - downAt >= 500L) showMenu()
                    else v.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating proxy bubble", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(): Notification = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_notification).setContentTitle("FreeProxy bubble is active")
        .setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()

    override fun onDestroy() {
        menu?.dismiss(); bubble?.let { runCatching { wm.removeView(it) } }; bubble = null
        scope.cancel(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "floating_bubble"
        const val ACTION_CLOSE = "tech.xvanturing.freeproxy.overlay.CLOSE"
        fun start(context: Context) { if (Settings.canDrawOverlays(context)) ContextCompat.startForegroundService(context, Intent(context, FloatingBubbleService::class.java)) }
        fun stop(context: Context) { context.stopService(Intent(context, FloatingBubbleService::class.java)) }
    }
}
