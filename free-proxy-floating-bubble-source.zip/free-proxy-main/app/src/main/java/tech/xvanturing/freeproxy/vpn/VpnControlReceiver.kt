package tech.xvanturing.freeproxy.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 处理通知栏上的「断开」动作。 */
class VpnControlReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_STOP) {
            FreeProxyVpnService.stop(context)
        }
    }

    companion object {
        const val ACTION_STOP = "tech.xvanturing.freeproxy.action.NOTIFICATION_STOP"
    }
}
