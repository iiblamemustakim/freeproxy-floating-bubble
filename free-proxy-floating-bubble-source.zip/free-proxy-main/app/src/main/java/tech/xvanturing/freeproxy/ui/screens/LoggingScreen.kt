package tech.xvanturing.freeproxy.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.ui.MainViewModel
import tech.xvanturing.freeproxy.ui.components.AppIcon
import tech.xvanturing.freeproxy.ui.components.FreeProxyTextField
import tech.xvanturing.freeproxy.ui.components.ResponsiveContainer
import tech.xvanturing.freeproxy.ui.components.rememberAppLabel
import tech.xvanturing.freeproxy.ui.theme.ConnectedGreen
import tech.xvanturing.freeproxy.ui.theme.ConnectingAmber
import tech.xvanturing.freeproxy.util.formatBitrate
import tech.xvanturing.freeproxy.vpn.VpnStateHolder
import tech.xvanturing.freeproxy.vpn.log.LogEntry
import tech.xvanturing.freeproxy.vpn.log.LogKind
import tech.xvanturing.freeproxy.vpn.log.LogLevel
import tech.xvanturing.freeproxy.vpn.log.TunnelLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoggingScreen(viewModel: MainViewModel, contentPadding: PaddingValues) {
    val entries by TunnelLog.entries.collectAsStateWithLifecycle()
    val paused by TunnelLog.paused.collectAsStateWithLifecycle()
    val vpnState by VpnStateHolder.state.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var query by rememberSaveable { mutableStateOf("") }
    var appFilter by rememberSaveable { mutableStateOf<String?>(null) }

    val filteredEntries = remember(entries, query, appFilter) {
        entries.filter { entry ->
            (appFilter == null || entry.packageName == appFilter) &&
                (
                    query.isBlank() ||
                        entry.title.contains(query, ignoreCase = true) ||
                        entry.status?.contains(query, ignoreCase = true) == true ||
                        entry.packageName?.contains(query, ignoreCase = true) == true
                    )
        }
    }

    // 只有当用户本来就停在底部时才自动跟随，否则会把正在往回翻的人拽走
    val isPinnedToBottom by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull() ?: return@derivedStateOf true
            last.index >= info.totalItemsCount - 2
        }
    }

    LaunchedEffect(filteredEntries.size) {
        if (filteredEntries.isNotEmpty() && isPinnedToBottom) {
            listState.animateScrollToItem(filteredEntries.lastIndex)
        }
    }

    // SAF 让用户自己挑保存位置，不需要任何存储权限
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv"),
    ) { uri ->
        if (uri != null) {
            val success = runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(TunnelLog.toCsv(filteredEntries).toByteArray(Charsets.UTF_8))
                } ?: error("cannot open output stream")
            }.isSuccess
            Toast.makeText(
                context,
                if (success) R.string.log_export_success else R.string.log_export_failed,
                Toast.LENGTH_SHORT,
            ).show()
        }
    }

    ResponsiveContainer {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(stringResource(R.string.log_title)) },
            actions = {
                IconButton(onClick = { TunnelLog.setPaused(!paused) }) {
                    Icon(
                        if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                        contentDescription = stringResource(
                            if (paused) R.string.log_resume else R.string.log_pause,
                        ),
                        tint = if (paused) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                    )
                }
                IconButton(
                    onClick = {
                        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                        exportLauncher.launch("freeproxy-log-$stamp.csv")
                    },
                ) {
                    Icon(
                        Icons.Rounded.FileDownload,
                        contentDescription = stringResource(R.string.log_export),
                    )
                }
                IconButton(onClick = TunnelLog::clear) {
                    Icon(
                        Icons.Rounded.DeleteSweep,
                        contentDescription = stringResource(R.string.log_clear),
                    )
                }
            },
        )

        FilterBar(
            query = query,
            onQueryChange = { query = it },
            appFilter = appFilter,
            onAppFilterChange = { appFilter = it },
            appOptions = remember(entries) { entries.mapNotNull { it.packageName }.distinct() },
        )

        ThroughputBar(
            downloadBytesPerSecond = vpnState.downloadBytesPerSecond,
            uploadBytesPerSecond = vpnState.uploadBytesPerSecond,
        )

        Box(modifier = Modifier.fillMaxSize()) {
            when {
                filteredEntries.isNotEmpty() -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        bottom = contentPadding.calculateBottomPadding() + 16.dp,
                    ),
                ) {
                    items(filteredEntries, key = { it.id }) { entry ->
                        LogRow(
                            entry = entry,
                            blockedDomains = settings.dnsBlockDomains,
                            onBlockDomain = { domain ->
                                viewModel.addDnsBlockDomains(listOf(domain), entry.packageName)
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.log_block_domain_added, domain),
                                    Toast.LENGTH_SHORT,
                                ).show()
                            },
                        )
                    }
                }
                entries.isEmpty() -> EmptyLog(bottomPadding = contentPadding.calculateBottomPadding())
                else -> NoMatch(bottomPadding = contentPadding.calculateBottomPadding())
            }

            // 往回翻看历史时才出现，避免挡住最新的日志
            if (!isPinnedToBottom && filteredEntries.isNotEmpty()) {
                FloatingActionButton(
                    onClick = {
                        scope.launch { listState.animateScrollToItem(filteredEntries.lastIndex) }
                    },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = contentPadding.calculateBottomPadding() + 16.dp)
                        .size(48.dp),
                ) {
                    Icon(
                        Icons.Rounded.ArrowDownward,
                        contentDescription = stringResource(R.string.log_scroll_to_bottom),
                    )
                }
            }
        }
    }
    }
}

/** 筛选栏横滑最多摆的应用数，多余的收进弹窗。 */
private const val MAX_FILTER_CHIPS = 5

@Composable
private fun FilterBar(
    query: String,
    onQueryChange: (String) -> Unit,
    appFilter: String?,
    onAppFilterChange: (String?) -> Unit,
    appOptions: List<String>,
) {
    var pickerOpen by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        FreeProxyTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text(stringResource(R.string.log_search)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = null)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        )
        if (appOptions.isNotEmpty()) {
            // 横滑最多摆 5 个，顺序稳定不跟随日志刷新；再多的收进弹窗
            val chipApps = remember(appOptions) { appOptions.take(MAX_FILTER_CHIPS) }
            // 选中的应用不在前 5 个里时，由「更多」chip 代为展示
            val hiddenSelection = appFilter != null && appFilter !in chipApps
            val hasMore = appOptions.size > MAX_FILTER_CHIPS
            val rowState = rememberLazyListState()

            // 从弹窗选中滑动区里的应用时，滚过去让高亮进入视野
            LaunchedEffect(appFilter) {
                val target = when {
                    appFilter == null -> 0
                    hiddenSelection -> 1 // 「更多」chip
                    else -> (if (hasMore) 2 else 1) + chipApps.indexOf(appFilter)
                }
                if (target >= 0) rowState.animateScrollToItem(target)
            }

            LazyRow(
                state = rowState,
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 8.dp),
            ) {
                item {
                    FilterChip(
                        selected = appFilter == null,
                        onClick = { onAppFilterChange(null) },
                        label = { Text(stringResource(R.string.log_filter_all)) },
                    )
                }
                // 应用一多横滑很难找，留一个弹窗入口（可搜索）
                if (hasMore) {
                    item {
                        FilterChip(
                            selected = hiddenSelection,
                            onClick = { pickerOpen = true },
                            label = {
                                Text(
                                    text = if (hiddenSelection) {
                                        rememberAppLabel(appFilter!!)
                                    } else {
                                        stringResource(R.string.log_filter_more)
                                    },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            leadingIcon = {
                                if (hiddenSelection) {
                                    AppIcon(
                                        packageName = appFilter,
                                        modifier = Modifier.size(18.dp),
                                    )
                                } else {
                                    Icon(
                                        Icons.Rounded.Apps,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            },
                            // 选中态下名字后面仍带「更多」图标，能认出这是弹窗入口
                            trailingIcon = if (hiddenSelection) {
                                {
                                    Icon(
                                        Icons.Rounded.Apps,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            } else {
                                null
                            },
                        )
                    }
                }
                items(chipApps, key = { it }) { packageName ->
                    FilterChip(
                        selected = appFilter == packageName,
                        onClick = { onAppFilterChange(packageName) },
                        label = {
                            Text(
                                text = rememberAppLabel(packageName),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        leadingIcon = {
                            AppIcon(packageName = packageName, modifier = Modifier.size(18.dp))
                        },
                    )
                }
            }
        }
    }

    if (pickerOpen) {
        AppPickerDialog(
            appOptions = appOptions,
            selected = appFilter,
            onSelect = {
                onAppFilterChange(it)
                pickerOpen = false
            },
            onDismiss = { pickerOpen = false },
        )
    }
}

@Composable
private fun AppPickerDialog(
    appOptions: List<String>,
    selected: String?,
    onSelect: (String?) -> Unit,
    onDismiss: () -> Unit,
) {
    var pickerQuery by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current

    // 一次性解析全部应用名，搜索才能按名字匹配
    val labeledApps by produceState(
        initialValue = appOptions.map { it to it },
        appOptions,
    ) {
        value = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            appOptions.map { pkg ->
                pkg to runCatching {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                }.getOrDefault(pkg)
            }
        }
    }

    val shown = remember(labeledApps, pickerQuery) {
        labeledApps.filter { (pkg, label) ->
            pickerQuery.isBlank() ||
                label.contains(pickerQuery, ignoreCase = true) ||
                pkg.contains(pickerQuery, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.log_filter_title)) },
        text = {
            Column {
                FreeProxyTextField(
                    value = pickerQuery,
                    onValueChange = { pickerQuery = it },
                    placeholder = { Text(stringResource(R.string.apps_search)) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    item {
                        AppPickerRow(
                            label = stringResource(R.string.log_filter_all),
                            packageName = null,
                            selected = selected == null,
                            onClick = { onSelect(null) },
                        )
                    }
                    items(shown, key = { it.first }) { (pkg, label) ->
                        AppPickerRow(
                            label = label,
                            packageName = pkg,
                            selected = selected == pkg,
                            onClick = { onSelect(pkg) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

@Composable
private fun AppPickerRow(
    label: String,
    packageName: String?,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (packageName != null) {
            AppIcon(packageName = packageName, modifier = Modifier.size(28.dp))
        } else {
            Icon(
                Icons.Rounded.Apps,
                contentDescription = null,
                modifier = Modifier.size(28.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (selected) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun ThroughputBar(
    downloadBytesPerSecond: Long,
    uploadBytesPerSecond: Long,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Rounded.ArrowDownward,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = formatBitrate(downloadBytesPerSecond),
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = formatBitrate(uploadBytesPerSecond),
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.End,
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            Icons.Rounded.ArrowUpward,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * 单行日志。带域名的记录（DNS 查询、按主机名建立的连接）长按可把它
 * 加入 DNS 拦截名单，来源应用一并记录。
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LogRow(
    entry: LogEntry,
    blockedDomains: Set<String>,
    onBlockDomain: (String) -> Unit,
) {
    val background = when (entry.level) {
        LogLevel.NEUTRAL -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        LogLevel.SUCCESS -> ConnectedGreen.copy(alpha = 0.16f)
        LogLevel.NOTICE -> ConnectingAmber.copy(alpha = 0.20f)
        LogLevel.FAILURE -> MaterialTheme.colorScheme.errorContainer
    }

    var menuOpen by remember { mutableStateOf(false) }
    // 与 MainViewModel 的规范化保持一致：小写、去根点
    val domain = entry.domain?.trim()?.lowercase()?.removeSuffix(".")?.ifEmpty { null }

    Box {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(background)
                .then(
                    if (domain != null) {
                        Modifier.combinedClickable(
                            onClick = {},
                            onLongClick = { menuOpen = true },
                        )
                    } else {
                        Modifier
                    },
                )
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (entry.kind == LogKind.SERVICE) {
                Icon(
                    imageVector = Icons.Rounded.SwapHoriz,
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
            } else {
                AppIcon(packageName = entry.packageName, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = rememberTimestamp(entry.timestampMillis),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = entry.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }

            if (entry.status != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = entry.status,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (entry.level == LogLevel.FAILURE) {
                        MaterialTheme.colorScheme.onErrorContainer
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
        }

        if (domain != null) {
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
            ) {
                val alreadyBlocked = domain in blockedDomains
                DropdownMenuItem(
                    text = {
                        Text(
                            text = if (alreadyBlocked) {
                                stringResource(R.string.log_block_domain_exists)
                            } else {
                                stringResource(R.string.log_block_domain, domain)
                            },
                        )
                    },
                    enabled = !alreadyBlocked,
                    onClick = {
                        menuOpen = false
                        onBlockDomain(domain)
                    },
                )
            }
        }
    }
}

@Composable
private fun EmptyLog(bottomPadding: Dp) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp, vertical = 48.dp)
            .padding(bottom = bottomPadding),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = stringResource(R.string.log_empty),
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.log_empty_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun NoMatch(bottomPadding: Dp) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp, vertical = 48.dp)
            .padding(bottom = bottomPadding),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = stringResource(R.string.log_no_match),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun rememberTimestamp(millis: Long): String {
    // SimpleDateFormat 不是线程安全的，但这里只在组合阶段（主线程）用
    val formatter = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }
    return remember(millis) { formatter.format(Date(millis)) }
}
