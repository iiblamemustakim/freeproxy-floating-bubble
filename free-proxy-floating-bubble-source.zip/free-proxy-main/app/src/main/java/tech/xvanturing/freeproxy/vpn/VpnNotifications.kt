package tech.xvanturing.freeproxy.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.ui.MainActivity
import tech.xvanturing.freeproxy.util.formatBytes

/** 常驻通知：显示隧道状态、实时流量，并提供一键断开。 */
object VpnNotifications {

    const val CHANNEL_ID = "vpn_status"
    const val NOTIFICATION_ID = 1001

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService<NotificationManager>() ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = context.getString(R.string.notif_channel_desc)
            setShowBadge(false)
            enableVibration(false)
        }
        manager.createNotificationChannel(channel)
    }

    fun build(context: Context, state: VpnState): Notification {
        val title = when (state.status) {
            VpnStatus.CONNECTED -> context.getString(
                R.string.notif_connected_title,
                state.profileName.orEmpty(),
            )

            else -> context.getString(R.string.notif_connecting_title)
        }
        val text = context.getString(
            R.string.notif_traffic,
            formatBytes(state.uploadBytes),
            formatBytes(state.downloadBytes),
        )

        val contentIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val stopIntent = PendingIntent.getBroadcast(
            context,
            1,
            Intent(context, VpnControlReceiver::class.java)
                .setAction(VpnControlReceiver.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(
                R.drawable.ic_notification,
                context.getString(R.string.notif_action_stop),
                stopIntent,
            )
            .build()
    }
}
