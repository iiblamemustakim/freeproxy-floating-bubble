package tech.xvanturing.freeproxy.ui.components

import android.content.Context
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val ICON_SIZE_PX = 120

/** 图标解码不便宜，列表滚动时靠这个缓存避免反复解码同一个包。 */
private val iconCache = LruCache<String, ImageBitmap>(96)

/** 显示某个应用的图标；包名为空或应用已卸载时留白占位。 */
@Composable
fun AppIcon(packageName: String?, modifier: Modifier = Modifier) {
    if (packageName.isNullOrEmpty()) {
        Box(modifier)
        return
    }
    val context = LocalContext.current
    val icon by produceState<ImageBitmap?>(iconCache[packageName], packageName) {
        if (value == null) {
            value = withContext(Dispatchers.IO) { loadIcon(context, packageName) }
        }
    }
    val bitmap = icon
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = modifier)
    } else {
        Box(modifier)
    }
}

private fun loadIcon(context: Context, packageName: String): ImageBitmap? = runCatching {
    val drawable = context.packageManager.getApplicationIcon(packageName)
    val bitmap = drawable.toBitmap(width = ICON_SIZE_PX, height = ICON_SIZE_PX).asImageBitmap()
    iconCache.put(packageName, bitmap)
    bitmap
}.getOrNull()
