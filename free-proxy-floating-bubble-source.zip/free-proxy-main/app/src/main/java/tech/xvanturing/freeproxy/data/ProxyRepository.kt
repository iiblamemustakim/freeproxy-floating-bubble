package tech.xvanturing.freeproxy.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import tech.xvanturing.freeproxy.data.model.AppSettings
import tech.xvanturing.freeproxy.data.model.ProxyProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import java.util.UUID

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "freeproxy")

/**
 * 配置与设置的唯一数据源。
 *
 * 数据量很小（几十条配置），因此直接用 DataStore Preferences 存 JSON 字符串，
 * 不引入 Room —— 省掉一整套注解处理器，构建也更稳。
 */
class ProxyRepository(context: Context) {

    private val store = context.applicationContext.dataStore

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val profiles: Flow<List<ProxyProfile>> = store.data.map { prefs ->
        prefs[KEY_PROFILES].decodeOr(emptyList())
    }

    val activeProfileId: Flow<String?> = store.data.map { prefs -> prefs[KEY_ACTIVE_ID] }

    val settings: Flow<AppSettings> = store.data.map { prefs ->
        prefs[KEY_SETTINGS].decodeOr(AppSettings())
    }

    /** 当前选中的配置；选中项被删除后自动退化为空。 */
    val activeProfile: Flow<ProxyProfile?> =
        combine(profiles, activeProfileId) { list, id ->
            list.firstOrNull { it.id == id } ?: list.firstOrNull()
        }

    suspend fun upsertProfile(profile: ProxyProfile) {
        store.edit { prefs ->
            val list = prefs[KEY_PROFILES].decodeOr(emptyList<ProxyProfile>()).toMutableList()
            val index = list.indexOfFirst { it.id == profile.id }
            if (index >= 0) list[index] = profile else list += profile
            prefs[KEY_PROFILES] = json.encodeToString(list)
            // 第一条配置自动设为当前配置
            if (prefs[KEY_ACTIVE_ID] == null) prefs[KEY_ACTIVE_ID] = profile.id
        }
    }

    suspend fun deleteProfile(id: String) {
        store.edit { prefs ->
            val list = prefs[KEY_PROFILES].decodeOr(emptyList<ProxyProfile>())
                .filterNot { it.id == id }
            prefs[KEY_PROFILES] = json.encodeToString(list)
            if (prefs[KEY_ACTIVE_ID] == id) {
                val next = list.firstOrNull()?.id
                if (next == null) prefs.remove(KEY_ACTIVE_ID) else prefs[KEY_ACTIVE_ID] = next
            }
        }
    }

    suspend fun setActiveProfile(id: String) {
        store.edit { prefs -> prefs[KEY_ACTIVE_ID] = id }
    }

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        store.edit { prefs ->
            val current = prefs[KEY_SETTINGS].decodeOr(AppSettings())
            prefs[KEY_SETTINGS] = json.encodeToString(transform(current))
        }
    }

    /** 供 VpnService 在启动瞬间取一份快照，避免持有长生命周期的 Flow 订阅。 */
    suspend fun snapshot(): Pair<ProxyProfile?, AppSettings> =
        activeProfile.first() to settings.first()

    fun newProfileId(): String = UUID.randomUUID().toString()

    private inline fun <reified T> String?.decodeOr(fallback: T): T {
        if (this.isNullOrEmpty()) return fallback
        return runCatching { json.decodeFromString<T>(this) }.getOrDefault(fallback)
    }

    private companion object {
        val KEY_PROFILES = stringPreferencesKey("profiles")
        val KEY_ACTIVE_ID = stringPreferencesKey("active_profile_id")
        val KEY_SETTINGS = stringPreferencesKey("settings")
    }
}
