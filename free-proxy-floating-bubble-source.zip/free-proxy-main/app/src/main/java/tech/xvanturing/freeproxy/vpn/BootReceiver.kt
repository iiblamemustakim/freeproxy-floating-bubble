package tech.xvanturing.freeproxy.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.util.Log
import tech.xvanturing.freeproxy.AppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** 开机或应用更新后按需自动重连。 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val (profile, settings) = AppContainer.proxyRepository.snapshot()
                if (!settings.autoStart || profile == null) return@launch
                // 还没授予过 VPN 权限时无法静默启动，用户需要手动连一次
                if (VpnService.prepare(appContext) != null) {
                    Log.i(TAG, "尚未授予 VPN 权限，跳过自动连接")
                    return@launch
                }
                FreeProxyVpnService.start(appContext)
            } catch (e: Exception) {
                // 部分系统版本会限制开机阶段启动前台服务，失败就安静跳过
                Log.w(TAG, "自动连接失败：${e.message}")
            } finally {
                pendingResult.finish()
            }
        }
    }

    private companion object {
        const val TAG = "BootReceiver"
    }
}
