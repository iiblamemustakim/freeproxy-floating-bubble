package tech.xvanturing.freeproxy

import android.app.Application
import tech.xvanturing.freeproxy.vpn.VpnNotifications

class FreeProxyApp : Application() {

    override fun onCreate() {
        super.onCreate()
        AppContainer.init(this)
        VpnNotifications.ensureChannel(this)
    }
}
