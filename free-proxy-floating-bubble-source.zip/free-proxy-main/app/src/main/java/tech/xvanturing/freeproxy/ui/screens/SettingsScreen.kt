package tech.xvanturing.freeproxy.ui.screens

import android.os.Build
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.data.model.AppRoutingMode
import tech.xvanturing.freeproxy.data.model.ThemeMode
import tech.xvanturing.freeproxy.ui.MainViewModel
import tech.xvanturing.freeproxy.ui.components.FreeProxyTextField
import tech.xvanturing.freeproxy.ui.components.SectionTitle
import tech.xvanturing.freeproxy.ui.components.SettingRow
import tech.xvanturing.freeproxy.ui.components.SwitchRow
import tech.xvanturing.freeproxy.ui.components.ResponsiveContainer
import tech.xvanturing.freeproxy.vpn.CountryCode
import tech.xvanturing.freeproxy.vpn.FloatingBubbleService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    contentPadding: PaddingValues,
    onOpenPerAppProxy: () -> Unit,
    onOpenDnsBlock: () -> Unit,
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showThemeDialog by remember { mutableStateOf(false) }
    var showDnsDialog by remember { mutableStateOf(false) }
    var showMtuDialog by remember { mutableStateOf(false) }
    var showCountryDialog by remember { mutableStateOf(false) }

    val versionName = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull().orEmpty()
    }

    ResponsiveContainer {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(stringResource(R.string.settings_title)) })
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = contentPadding.calculateBottomPadding() + 24.dp),
        ) {
        SectionTitle(
            text = stringResource(R.string.settings_appearance),
            modifier = Modifier.padding(start = 16.dp),
        )
        SettingRow(
            title = stringResource(R.string.settings_theme),
            subtitle = stringResource(settings.themeMode.labelRes),
            onClick = { showThemeDialog = true },
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SwitchRow(
                title = stringResource(R.string.settings_dynamic_color),
                subtitle = stringResource(R.string.settings_dynamic_color_desc),
                checked = settings.dynamicColor,
                onCheckedChange = viewModel::setDynamicColor,
            )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        SectionTitle(text = "Floating controls", modifier = Modifier.padding(start = 16.dp))
        SwitchRow(
            title = "Floating proxy bubble",
            subtitle = "Keep a draggable connect/disconnect bubble above other apps",
            checked = settings.floatingBubbleEnabled,
            onCheckedChange = { enabled ->
                if (enabled && !Settings.canDrawOverlays(context)) {
                    viewModel.setFloatingBubbleEnabled(true)
                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                } else {
                    viewModel.setFloatingBubbleEnabled(enabled)
                    if (enabled) FloatingBubbleService.start(context) else FloatingBubbleService.stop(context)
                }
            },
        )
        SettingRow(title = "Country code list", subtitle = "Search by country name or short code", onClick = { showCountryDialog = true })

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        SectionTitle(
            text = stringResource(R.string.settings_network),
            modifier = Modifier.padding(start = 16.dp),
        )
        SettingRow(
            title = stringResource(R.string.settings_per_app),
            subtitle = stringResource(settings.routingMode.summaryRes),
            onClick = onOpenPerAppProxy,
        )
        SettingRow(
            title = stringResource(R.string.settings_dns_block),
            subtitle = stringResource(
                if (settings.dnsBlockEnabled) R.string.dns_block_on else R.string.dns_block_off,
            ),
            onClick = onOpenDnsBlock,
        )
        SettingRow(
            title = stringResource(R.string.settings_dns),
            subtitle = settings.dnsServer,
            onClick = { showDnsDialog = true },
        )
        SettingRow(
            title = stringResource(R.string.settings_mtu),
            subtitle = settings.mtu.toString(),
            onClick = { showMtuDialog = true },
        )
        SwitchRow(
            title = stringResource(R.string.settings_bypass_lan),
            subtitle = stringResource(R.string.settings_bypass_lan_desc),
            checked = settings.bypassLan,
            onCheckedChange = viewModel::setBypassLan,
        )
        SwitchRow(
            title = stringResource(R.string.settings_ipv6),
            subtitle = stringResource(R.string.settings_ipv6_desc),
            checked = settings.enableIpv6,
            onCheckedChange = viewModel::setEnableIpv6,
        )
        SwitchRow(
            title = stringResource(R.string.settings_stop_on_loss),
            subtitle = stringResource(R.string.settings_stop_on_loss_desc),
            checked = settings.stopOnNetworkLoss,
            onCheckedChange = viewModel::setStopOnNetworkLoss,
        )
        SwitchRow(
            title = stringResource(R.string.settings_auto_start),
            subtitle = stringResource(R.string.settings_auto_start_desc),
            checked = settings.autoStart,
            onCheckedChange = viewModel::setAutoStart,
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        SectionTitle(
            text = stringResource(R.string.settings_about),
            modifier = Modifier.padding(start = 16.dp),
        )
        SettingRow(
            title = stringResource(R.string.settings_version),
            subtitle = versionName,
        )
        SettingRow(
            title = stringResource(R.string.settings_reset),
            onClick = viewModel::resetSettings,
        )
        }
        }
    }

    if (showCountryDialog) {
        CountryListDialog(onDismiss = { showCountryDialog = false })
    }

    if (showThemeDialog) {
        ThemeDialog(
            current = settings.themeMode,
            onSelect = {
                viewModel.setThemeMode(it)
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false },
        )
    }

    if (showDnsDialog) {
        TextInputDialog(
            title = stringResource(R.string.settings_dns),
            initial = settings.dnsServer,
            keyboardType = KeyboardType.Uri,
            onConfirm = { value ->
                if (value.isNotBlank()) viewModel.setDnsServer(value.trim())
                showDnsDialog = false
            },
            onDismiss = { showDnsDialog = false },
        )
    }

    if (showMtuDialog) {
        TextInputDialog(
            title = stringResource(R.string.settings_mtu),
            initial = settings.mtu.toString(),
            keyboardType = KeyboardType.Number,
            onConfirm = { value ->
                value.trim().toIntOrNull()?.let(viewModel::setMtu)
                showMtuDialog = false
            },
            onDismiss = { showMtuDialog = false },
        )
    }
}

@Composable
private fun CountryListDialog(onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val matches = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) CountryCode.all else CountryCode.all.filter {
            it.name.lowercase().contains(q) || it.code.lowercase().contains(q)
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Country codes") },
        text = {
            Column {
                FreeProxyTextField(value = query, onValueChange = { query = it }, singleLine = true, placeholder = { Text("Search country or code") })
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(matches) { country ->
                        SettingRow(title = "${country.flag}  ${country.name}", subtitle = country.code)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun ThemeDialog(
    current: ThemeMode,
    onSelect: (ThemeMode) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_theme)) },
        text = {
            Column(modifier = Modifier.selectableGroup()) {
                ThemeMode.entries.forEach { mode ->
                    SettingRow(
                        title = stringResource(mode.labelRes),
                        onClick = { onSelect(mode) },
                        trailing = {
                            RadioButton(selected = mode == current, onClick = { onSelect(mode) })
                        },
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

@Composable
private fun TextInputDialog(
    title: String,
    initial: String,
    keyboardType: KeyboardType,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            FreeProxyTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

private val ThemeMode.labelRes: Int
    get() = when (this) {
        ThemeMode.SYSTEM -> R.string.settings_theme_system
        ThemeMode.LIGHT -> R.string.settings_theme_light
        ThemeMode.DARK -> R.string.settings_theme_dark
    }

private val AppRoutingMode.summaryRes: Int
    get() = when (this) {
        AppRoutingMode.ALL -> R.string.apps_mode_all
        AppRoutingMode.ALLOW -> R.string.apps_mode_allow
        AppRoutingMode.DISALLOW -> R.string.apps_mode_disallow
    }
