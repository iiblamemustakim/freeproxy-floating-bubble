package tech.xvanturing.freeproxy.ui

import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import tech.xvanturing.freeproxy.AppContainer
import tech.xvanturing.freeproxy.vpn.FloatingBubbleService
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tech.xvanturing.freeproxy.ui.theme.FreeProxyTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels { MainViewModel.Factory }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val enabled = AppContainer.proxyRepository.settings.first().floatingBubbleEnabled
            if (enabled && Settings.canDrawOverlays(this@MainActivity)) FloatingBubbleService.start(this@MainActivity)
            else if (enabled) AppContainer.proxyRepository.updateSettings { it.copy(floatingBubbleEnabled = false) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            FreeProxyTheme(
                themeMode = settings.themeMode,
                dynamicColor = settings.dynamicColor,
            ) {
                FreeProxyRoot(viewModel)
            }
        }
        // HyperOS/MIUI（Android 15 之前的版本）有两个兼容问题：
        // 1) DecorView 不会把 setDecorFitsSystemWindows(false) 翻译成 LAYOUT_HIDE_NAVIGATION
        //    等布局标记（dumpsys 里 FIT_INSETS_CONTROLLED 有、vsysui 没有）；
        // 2) 窗口管理只在带 TRANSLUCENT_* 标记时才让内容延伸进系统栏区域。
        // 结果是手势导航栏区域没有应用内容，底部露出一条白边。
        // 这两个标记在 API 35+ 会让系统误加对比度遮罩，因此只对旧版 MIUI 应用。
        if (Build.VERSION.SDK_INT < 35 && Build.MANUFACTURER.equals("Xiaomi", ignoreCase = true)) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION or
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
            )
        }
    }
}
