package tech.xvanturing.freeproxy.data

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import tech.xvanturing.freeproxy.data.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 读取可参与分应用代理的已安装应用。 */
class AppListRepository(context: Context) {

    private val appContext = context.applicationContext
    private val ownPackage = appContext.packageName

    /**
     * 只返回申请了 INTERNET 权限的应用 —— 没有网络权限的应用放进名单毫无意义，
     * 而且 [android.net.VpnService.Builder.addAllowedApplication] 对它们也不会有任何效果。
     */
    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = appContext.packageManager
        val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        packages.asSequence()
            .filter { it.packageName != ownPackage }
            .filter { pkg ->
                pkg.requestedPermissions?.any { it == Manifest.permission.INTERNET } == true
            }
            .mapNotNull { pkg ->
                val info = pkg.applicationInfo ?: return@mapNotNull null
                AppInfo(
                    packageName = pkg.packageName,
                    label = runCatching { pm.getApplicationLabel(info).toString() }
                        .getOrDefault(pkg.packageName),
                    isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                )
            }
            .sortedWith(compareBy({ it.isSystem }, { it.label.lowercase() }))
            .toList()
    }
}
