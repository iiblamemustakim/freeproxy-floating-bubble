package tech.xvanturing.freeproxy.util

import java.util.Locale

/** 把字节数格式化成便于阅读的形式。 */
fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    var value = bytes / 1024.0
    val units = arrayOf("KB", "MB", "GB", "TB")
    var index = 0
    while (value >= 1024 && index < units.lastIndex) {
        value /= 1024
        index++
    }
    return String.format(Locale.US, if (value >= 100) "%.0f %s" else "%.1f %s", value, units[index])
}

/**
 * 把字节每秒折算成比特率显示。
 * 网络速率习惯上按比特计（1 字节 = 8 比特），与参考实现的 Mbit/s 口径一致。
 */
fun formatBitrate(bytesPerSecond: Long): String {
    val bits = bytesPerSecond * 8
    return when {
        bits < 1_000 -> "$bits bit/s"
        bits < 1_000_000 -> String.format(Locale.US, "%.1f kbit/s", bits / 1_000.0)
        bits < 1_000_000_000 -> String.format(Locale.US, "%.1f Mbit/s", bits / 1_000_000.0)
        else -> String.format(Locale.US, "%.2f Gbit/s", bits / 1_000_000_000.0)
    }
}

/** 把毫秒时长格式化成 h:mm:ss / m:ss。 */
fun formatDuration(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%d:%02d", minutes, seconds)
    }
}
