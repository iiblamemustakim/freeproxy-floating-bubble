package tech.xvanturing.freeproxy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.data.model.DnsMode
import tech.xvanturing.freeproxy.data.model.ProxyProfile
import tech.xvanturing.freeproxy.data.model.ProxyType
import tech.xvanturing.freeproxy.ui.components.FreeProxyTextField
import tech.xvanturing.freeproxy.ui.components.isWideLayout
import tech.xvanturing.freeproxy.ui.theme.ConnectedGreen
import tech.xvanturing.freeproxy.vpn.proxy.ProxyTestResult
import tech.xvanturing.freeproxy.vpn.proxy.ProxyTester
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditorDialog(
    initial: ProxyProfile,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (ProxyProfile) -> Unit,
) {
    var name by remember { mutableStateOf(initial.name) }
    var type by remember { mutableStateOf(initial.type) }
    var host by remember { mutableStateOf(initial.host) }
    var port by remember { mutableStateOf(initial.port.toString()) }
    var username by remember { mutableStateOf(initial.username) }
    var password by remember { mutableStateOf(initial.password) }
    var udpOverSocks by remember { mutableStateOf(initial.udpOverSocks) }
    var dnsMode by remember { mutableStateOf(initial.dnsMode) }
    var passwordVisible by remember { mutableStateOf(false) }
    var validate by remember { mutableStateOf(false) }
    var testState by remember { mutableStateOf<TestState>(TestState.Idle) }

    val scope = rememberCoroutineScope()
    val portNumber = port.toIntOrNull()
    val nameError = validate && name.isBlank()
    val hostError = validate && host.isBlank()
    val portError = validate && (portNumber == null || portNumber !in 1..65535)

    fun currentProfile(): ProxyProfile = initial.copy(
        name = name.trim(),
        type = type,
        host = host.trim(),
        port = portNumber ?: 0,
        username = username.trim(),
        password = password,
        udpOverSocks = udpOverSocks,
        dnsMode = dnsMode,
    )

    val wide = isWideLayout()

    fun trySave() {
        validate = true
        val validPort = port.toIntOrNull()
        if (name.isNotBlank() && host.isNotBlank() && validPort != null && validPort in 1..65535) {
            onSave(currentProfile())
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        // 不让对话框窗口自己避让系统栏，否则遮罩会盖在状态栏和导航栏上，
        // 弹窗一开系统栏就变成一条灰边。避让改由下面的 Scaffold 自己做。
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        // 对话框是独立的 window，Activity 上设好的系统栏外观不会继承过来 ——
        // 不跟着改的话，浅色弹窗顶上会是一排看不清的白色状态栏图标
        val dialogView = LocalView.current
        val lightSystemBars = MaterialTheme.colorScheme.surface.luminance() > 0.5f
        SideEffect {
            val window = (dialogView.parent as? DialogWindowProvider)?.window
                ?: return@SideEffect
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = lightSystemBars
                isAppearanceLightNavigationBars = lightSystemBars
            }
        }

        // 大屏上全屏铺满会显得空旷，收成居中卡片更接近平板的对话框习惯
        Surface(
            modifier = if (wide) {
                Modifier
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .widthIn(max = 560.dp)
                    .fillMaxHeight(0.92f)
            } else {
                Modifier.fillMaxSize()
            },
            shape = if (wide) RoundedCornerShape(28.dp) else RectangleShape,
        ) {
            Scaffold(
                topBar = {
                    Column {
                        TopAppBar(
                            title = {
                                Text(
                                    stringResource(
                                        if (isNew) R.string.profile_add else R.string.profile_edit,
                                    ),
                                )
                            },
                            navigationIcon = {
                                IconButton(onClick = onDismiss) {
                                    Icon(
                                        Icons.Rounded.Close,
                                        contentDescription = stringResource(R.string.cancel),
                                    )
                                }
                            },
                            actions = {
                                TextButton(onClick = { trySave() }) {
                                    Text(stringResource(R.string.save))
                                }
                            },
                            // 大屏是圆角卡片，标题栏不能自己再顶一层状态栏高度
                            windowInsets = if (wide) {
                                WindowInsets(0)
                            } else {
                                TopAppBarDefaults.windowInsets
                            },
                        )
                        HorizontalDivider()
                    }
                },
                // 连通性检测常配着改地址反复点，钉在底部比夹在滚动内容里顺手
                bottomBar = {
                    Surface(tonalElevation = 2.dp) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (wide) Modifier else Modifier.navigationBarsPadding(),
                                )
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            when (val state = testState) {
                                is TestState.Passed -> TestResultLine(
                                    text = stringResource(
                                        R.string.profile_test_success,
                                        state.elapsedMillis,
                                    ),
                                    color = ConnectedGreen,
                                )

                                is TestState.Failed -> TestResultLine(
                                    text = state.reason,
                                    color = MaterialTheme.colorScheme.error,
                                )

                                else -> Unit
                            }
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        testState = TestState.Running
                                        testState =
                                            when (val r = ProxyTester.test(currentProfile())) {
                                                is ProxyTestResult.Success ->
                                                    TestState.Passed(r.elapsedMillis)

                                                is ProxyTestResult.Failure ->
                                                    TestState.Failed(r.reason)
                                            }
                                    }
                                },
                                enabled = testState != TestState.Running,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                if (testState == TestState.Running) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(stringResource(R.string.profile_test_running))
                                } else {
                                    Text(stringResource(R.string.profile_test))
                                }
                            }
                        }
                    }
                },
                contentWindowInsets = WindowInsets(0),
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(padding)
                        .imePadding()
                        .padding(horizontal = 16.dp)
                        .padding(top = 16.dp, bottom = 24.dp),
                    // 组与组之间拉开，组内字段贴紧，靠间距区分层级而不是靠分隔线
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                ) {
                    FreeProxyTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(stringResource(R.string.profile_name)) },
                        singleLine = true,
                        isError = nameError,
                        supportingText = if (nameError) {
                            { Text(stringResource(R.string.error_name_required)) }
                        } else {
                            null
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )

                    EditorSection(stringResource(R.string.profile_type)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ProxyType.entries.forEach { candidate ->
                                FilterChip(
                                    selected = type == candidate,
                                    onClick = {
                                        // 端口还停在上一个协议的默认值时，顺手换成新协议的常用端口
                                        if (port == defaultPortFor(type).toString()) {
                                            port = defaultPortFor(candidate).toString()
                                        }
                                        type = candidate
                                    },
                                    label = { Text(candidate.displayName) },
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FreeProxyTextField(
                                value = host,
                                onValueChange = { host = it },
                                label = { Text(stringResource(R.string.profile_host)) },
                                singleLine = true,
                                isError = hostError,
                                supportingText = if (hostError) {
                                    { Text(stringResource(R.string.error_host_required)) }
                                } else {
                                    null
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                                modifier = Modifier.weight(2f),
                            )
                            FreeProxyTextField(
                                value = port,
                                onValueChange = { input ->
                                    port = input.filter { it.isDigit() }.take(5)
                                },
                                label = { Text(stringResource(R.string.profile_port)) },
                                singleLine = true,
                                isError = portError,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                ),
                                modifier = Modifier.weight(1f),
                            )
                        }
                        if (portError) {
                            Text(
                                text = stringResource(R.string.error_port_invalid),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }

                        if (type == ProxyType.SOCKS5) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.profile_udp),
                                        style = MaterialTheme.typography.bodyLarge,
                                    )
                                    Text(
                                        text = stringResource(R.string.profile_udp_hint),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Switch(
                                    checked = udpOverSocks,
                                    onCheckedChange = { udpOverSocks = it },
                                )
                            }
                        }
                    }

                    EditorSection(stringResource(R.string.profile_auth)) {
                        FreeProxyTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text(stringResource(R.string.profile_username)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        FreeProxyTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text(stringResource(R.string.profile_password)) },
                            singleLine = true,
                            visualTransformation = if (passwordVisible) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                            ),
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) {
                                            Icons.Rounded.VisibilityOff
                                        } else {
                                            Icons.Rounded.Visibility
                                        },
                                        contentDescription = null,
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }

                    EditorSection(stringResource(R.string.profile_dns_mode)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DnsMode.entries.forEach { candidate ->
                                FilterChip(
                                    selected = dnsMode == candidate,
                                    onClick = { dnsMode = candidate },
                                    label = { Text(stringResource(candidate.labelRes)) },
                                )
                            }
                        }
                        Text(
                            text = stringResource(dnsMode.descriptionRes),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

/** 编辑器里的一组字段：小标题 + 贴紧排列的内容。 */
@Composable
private fun EditorSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp),
        )
        content()
    }
}

/** 连通性检测的结果行，成功用绿色、失败用错误色。 */
@Composable
private fun TestResultLine(text: String, color: Color) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = color,
        modifier = Modifier.padding(horizontal = 4.dp),
    )
}

private fun defaultPortFor(type: ProxyType): Int = when (type) {
    ProxyType.SOCKS5 -> 1080
    ProxyType.HTTP -> 8080
}

/** 连通性检测的界面状态。 */
private sealed interface TestState {
    data object Idle : TestState
    data object Running : TestState
    data class Passed(val elapsedMillis: Long) : TestState
    data class Failed(val reason: String) : TestState
}

private val DnsMode.labelRes: Int
    get() = when (this) {
        DnsMode.PROXY -> R.string.dns_mode_proxy
        DnsMode.DIRECT -> R.string.dns_mode_direct
    }

private val DnsMode.descriptionRes: Int
    get() = when (this) {
        DnsMode.PROXY -> R.string.dns_mode_proxy_desc
        DnsMode.DIRECT -> R.string.dns_mode_direct_desc
    }
