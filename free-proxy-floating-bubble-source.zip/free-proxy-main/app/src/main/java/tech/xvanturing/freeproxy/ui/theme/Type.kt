package tech.xvanturing.freeproxy.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val defaults = Typography()

val FreeProxyTypography = defaults.copy(
    // 首页的流量数字用等宽字形，读数跳动时不会左右抖动
    headlineMedium = defaults.headlineMedium.copy(
        fontWeight = FontWeight.SemiBold,
    ),
    titleLarge = defaults.titleLarge.copy(
        fontWeight = FontWeight.SemiBold,
    ),
    labelLarge = defaults.labelLarge.copy(
        fontWeight = FontWeight.Medium,
    ),
)

/** 流量、时长等需要稳定宽度的读数。 */
val MonospaceNumber = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Medium,
    fontSize = 22.sp,
)
