package tech.xvanturing.freeproxy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.data.model.AppInfo
import tech.xvanturing.freeproxy.data.model.AppRoutingMode
import tech.xvanturing.freeproxy.ui.AppsViewModel
import tech.xvanturing.freeproxy.ui.components.AppIcon
import tech.xvanturing.freeproxy.ui.components.FreeProxyTextField
import tech.xvanturing.freeproxy.ui.components.ResponsiveContainer
import tech.xvanturing.freeproxy.ui.components.SwitchRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    viewModel: AppsViewModel = viewModel(factory = AppsViewModel.Factory),
) {
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val showSystemApps by viewModel.showSystemApps.collectAsStateWithLifecycle()

    val selectionEnabled = settings.routingMode != AppRoutingMode.ALL

    val visibleApps = remember(apps, query, showSystemApps) {
        val list = apps.orEmpty()
        val filtered = if (showSystemApps) list else list.filterNot { it.isSystem }
        if (query.isBlank()) {
            filtered
        } else {
            val needle = query.trim().lowercase()
            filtered.filter {
                it.label.lowercase().contains(needle) || it.packageName.lowercase().contains(needle)
            }
        }
    }

    ResponsiveContainer {
    Column(modifier = Modifier.fillMaxSize()) {
    TopAppBar(
        title = { Text(stringResource(R.string.apps_title)) },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
            }
        },
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            top = 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
    ) {
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = stringResource(R.string.apps_mode),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppRoutingMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.routingMode == mode,
                            onClick = { viewModel.setMode(mode) },
                            label = { Text(stringResource(mode.labelRes)) },
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(settings.routingMode.descriptionRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.apps_restart_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item {
            SwitchRow(
                title = stringResource(R.string.apps_show_system),
                checked = showSystemApps,
                onCheckedChange = viewModel::setShowSystemApps,
            )
        }

        if (selectionEnabled) {
            item {
                FreeProxyTextField(
                    value = query,
                    onValueChange = viewModel::setQuery,
                    placeholder = { Text(stringResource(R.string.apps_search)) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 8.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = pluralStringResource(
                            R.plurals.apps_selected,
                            settings.selectedApps.size,
                            settings.selectedApps.size,
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = { viewModel.selectAll(visibleApps.map { it.packageName }) },
                    ) {
                        Text(stringResource(R.string.apps_select_all))
                    }
                    TextButton(onClick = viewModel::clearSelection) {
                        Text(stringResource(R.string.apps_clear))
                    }
                }
                HorizontalDivider()
            }
        }

        if (apps == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }
        } else if (selectionEnabled) {
            items(visibleApps, key = { it.packageName }) { app ->
                AppRow(
                    app = app,
                    checked = app.packageName in settings.selectedApps,
                    onToggle = { viewModel.toggleApp(app.packageName) },
                )
            }
        }
    }
    }
    }
}

@Composable
private fun AppRow(
    app: AppInfo,
    checked: Boolean,
    onToggle: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(packageName = app.packageName, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = app.label, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = app.packageName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
    }
}


private val AppRoutingMode.labelRes: Int
    get() = when (this) {
        AppRoutingMode.ALL -> R.string.apps_mode_all
        AppRoutingMode.ALLOW -> R.string.apps_mode_allow
        AppRoutingMode.DISALLOW -> R.string.apps_mode_disallow
    }

private val AppRoutingMode.descriptionRes: Int
    get() = when (this) {
        AppRoutingMode.ALL -> R.string.apps_mode_all_desc
        AppRoutingMode.ALLOW -> R.string.apps_mode_allow_desc
        AppRoutingMode.DISALLOW -> R.string.apps_mode_disallow_desc
    }
