package tech.xvanturing.freeproxy.vpn.dns

import tech.xvanturing.freeproxy.data.model.AppSettings
import tech.xvanturing.freeproxy.vpn.net.DnsQuestion

/**
 * DNS 拦截规则的判定器，由启动时的设置快照构建，运行期间只读。
 *
 * 两类规则：
 *  - 按应用：名单内应用的全部查询都被拦截；
 *  - 按域名：example.com 命中自身与子域，*.example.com 只命中子域。
 *
 * 域名判定沿标签边界逐级向上匹配，复杂度是 O(域名的标签数)，
 * 另有一个 LRU 缓存承接热点域名。隧道多线程并发调用，所有入口都做了同步。
 */
class DnsBlocker(
    blockApps: Set<String>,
    blockDomains: Set<String>,
    private val responseIp: String,
) {

    private val blockApps: Set<String> = blockApps.toSet()

    /** 不带通配符的完整域名（命中自身与全部子域）。 */
    private val exactEntries: Set<String>

    /** 去掉 *. 前缀的域名（只命中子域）。 */
    private val wildcardEntries: Set<String>

    /** 域名判定结果缓存：规范化域名 → 是否命中。 */
    private val cacheLock = Any()
    private val cache = object : LinkedHashMap<String, Boolean>(CACHE_CAPACITY, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>): Boolean =
            size > CACHE_CAPACITY
    }

    init {
        val exact = mutableSetOf<String>()
        val wildcard = mutableSetOf<String>()
        blockDomains.forEach { raw ->
            val entry = normalize(raw)
            if (entry.isEmpty()) return@forEach
            if (entry.startsWith(WILDCARD_PREFIX)) {
                val suffix = entry.removePrefix(WILDCARD_PREFIX)
                if (suffix.isNotEmpty()) wildcard += suffix
            } else {
                exact += entry
            }
        }
        exactEntries = exact
        wildcardEntries = wildcard
    }

    /**
     * 判断这次查询是否应被拦截。
     *
     * @return 命中规则时返回应伪造的应答 IP；返回 null 表示正常转发。
     */
    fun resolve(question: DnsQuestion, packageName: String?): String? {
        if (isAppBlocked(packageName)) return responseIp
        return if (isDomainBlocked(normalize(question.name))) responseIp else null
    }

    /** 该应用的查询是否被全量拦截。 */
    fun isAppBlocked(packageName: String?): Boolean =
        packageName != null && packageName in blockApps

    /** 命中精确名单：自身或任意父级后缀；命中通配名单：仅父级后缀。 */
    private fun isDomainBlocked(name: String): Boolean {
        if (name.isEmpty() || (exactEntries.isEmpty() && wildcardEntries.isEmpty())) return false
        synchronized(cacheLock) { cache[name] }?.let { return it }

        var blocked = name in exactEntries
        var dot = name.indexOf('.')
        while (!blocked && dot >= 0) {
            val parent = name.substring(dot + 1)
            if (parent in exactEntries || parent in wildcardEntries) blocked = true
            dot = name.indexOf('.', dot + 1)
        }

        synchronized(cacheLock) { cache[name] = blocked }
        return blocked
    }

    /** 只用于测试观察缓存行为。 */
    internal val cacheSize: Int get() = synchronized(cacheLock) { cache.size }

    companion object {
        private const val WILDCARD_PREFIX = "*."
        private const val CACHE_CAPACITY = 1024

        /** 统一大小写并去掉末尾的根点，让 EXAMPLE.com. 与 example.com 等价。 */
        private fun normalize(name: String): String =
            name.trim().lowercase().removeSuffix(".")

        /** 功能未开启时返回 null，隧道侧连判定的开销都省掉。 */
        fun fromSettings(settings: AppSettings): DnsBlocker? =
            if (settings.dnsBlockEnabled) {
                DnsBlocker(
                    blockApps = settings.dnsBlockApps,
                    blockDomains = settings.dnsBlockDomains,
                    responseIp = settings.dnsBlockResponseIp,
                )
            } else {
                null
            }
    }
}
