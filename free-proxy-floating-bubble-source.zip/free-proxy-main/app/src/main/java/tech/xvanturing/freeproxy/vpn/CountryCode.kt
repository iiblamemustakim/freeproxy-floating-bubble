package tech.xvanturing.freeproxy.vpn

import java.util.Locale

/** Country is read only from the active profile username; no IP lookup is performed. */
object CountryCode {
    private val isoCodes = Locale.getISOCountries().toSet()

    // The country code must be a standalone uppercase token (for example __cr.CM).
    private val explicitCountryToken = Regex("(?:^|[._-])cr\\.([A-Z]{2})(?=$|[._-])")
    private val standaloneToken = Regex("(?:^|[._-])([A-Z]{2})(?=$|[._-])")

    fun fromUsername(username: String): String? {
        val explicit = explicitCountryToken.findAll(username).map { it.groupValues[1] }.lastOrNull { it in isoCodes }
        if (explicit != null) return explicit
        return standaloneToken.findAll(username).map { it.groupValues[1] }.lastOrNull { it in isoCodes }
    }

    fun flag(code: String?): String = if (code == null || code !in isoCodes) "💀" else
        code.uppercase(Locale.ROOT).map { Character.toChars(0x1F1E6 + it.code - 'A'.code).concatToString() }.joinToString("")

    fun displayName(code: String): String = Locale("", code).getDisplayCountry(Locale.ENGLISH)

    data class Country(val name: String, val code: String, val flag: String)

    val all: List<Country> by lazy {
        isoCodes.map { code -> Country(displayName(code), code, flag(code)) }
            .filter { it.name.isNotBlank() }
            .sortedBy { it.name.lowercase(Locale.ROOT) }
    }
}
