package tech.xvanturing.freeproxy.ui.screens

import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GppBad
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tech.xvanturing.freeproxy.R
import tech.xvanturing.freeproxy.data.model.AppRoutingMode
import tech.xvanturing.freeproxy.ui.MainViewModel
import tech.xvanturing.freeproxy.ui.components.StatTile
import tech.xvanturing.freeproxy.ui.components.ResponsiveContainer
import tech.xvanturing.freeproxy.ui.theme.ConnectedGreen
import tech.xvanturing.freeproxy.ui.theme.ConnectingAmber
import tech.xvanturing.freeproxy.ui.theme.DisconnectedGrey
import tech.xvanturing.freeproxy.util.formatBytes
import tech.xvanturing.freeproxy.util.formatDuration
import tech.xvanturing.freeproxy.vpn.VpnStatus
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    contentPadding: PaddingValues,
    onToggleConnection: (Boolean) -> Unit,
    onNavigateToProfiles: () -> Unit,
    // 转场淡出期间导航层会置为 false，避免“残影”FAB 响应点击
    fabEnabled: Boolean = true,
) {
    val state by viewModel.vpnState.collectAsStateWithLifecycle()
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var elapsed by remember { mutableLongStateOf(0L) }
    LaunchedEffect(state.connectedSince) {
        if (state.connectedSince == 0L) {
            elapsed = 0L
        } else {
            while (true) {
                elapsed = SystemClock.elapsedRealtime() - state.connectedSince
                delay(1000)
            }
        }
    }

    val statusColor by animateColorAsState(
        targetValue = when (state.status) {
            VpnStatus.CONNECTED -> ConnectedGreen
            VpnStatus.CONNECTING -> ConnectingAmber
            VpnStatus.ERROR -> MaterialTheme.colorScheme.error
            VpnStatus.DISCONNECTED -> DisconnectedGrey
        },
        label = "statusColor",
    )

    val statusLabel = stringResource(
        when (state.status) {
            VpnStatus.CONNECTED -> R.string.status_connected
            VpnStatus.CONNECTING -> R.string.status_connecting
            VpnStatus.ERROR -> R.string.status_error
            VpnStatus.DISCONNECTED -> R.string.status_disconnected
        },
    )

    ResponsiveContainer {
    Box(modifier = Modifier.fillMaxSize()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(
                top = contentPadding.calculateTopPadding() + 8.dp,
                // 给悬浮按钮留出高度，否则最后一张卡片会被压在按钮底下
                bottom = contentPadding.calculateBottomPadding() + 96.dp,
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(16.dp))

        StatusHero(
            status = state.status,
            statusColor = statusColor,
            statusLabel = statusLabel,
            elapsed = elapsed,
            hint = if (activeProfile == null) {
                stringResource(R.string.home_no_profile_hint)
            } else {
                activeProfile!!.name
            },
        )

        Spacer(Modifier.height(28.dp))

        if (state.status == VpnStatus.ERROR && state.errorMessage != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                ),
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Rounded.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Spacer(Modifier.size(12.dp))
                    Text(
                        text = state.errorMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        // 当前配置
        Card(
            onClick = onNavigateToProfiles,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.home_active_profile),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = activeProfile?.name ?: stringResource(R.string.home_no_profile),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    if (activeProfile != null) {
                        Text(
                            text = activeProfile!!.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Icon(Icons.Rounded.ChevronRight, contentDescription = null)
            }
        }

        Spacer(Modifier.height(16.dp))

        // 流量与会话
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                StatTile(
                    label = stringResource(R.string.home_upload),
                    value = formatBytes(state.uploadBytes),
                    modifier = Modifier.weight(1f),
                )
                StatTile(
                    label = stringResource(R.string.home_download),
                    value = formatBytes(state.downloadBytes),
                    modifier = Modifier.weight(1f),
                )
                StatTile(
                    label = stringResource(R.string.home_connections),
                    value = state.activeSessions.toString(),
                    modifier = Modifier.weight(1f),
                )
            }
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.home_routing),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = when (settings.routingMode) {
                        AppRoutingMode.ALL -> stringResource(R.string.home_routing_all)
                        AppRoutingMode.ALLOW -> pluralStringResource(
                            R.plurals.home_routing_allow,
                            settings.selectedApps.size,
                            settings.selectedApps.size,
                        )

                        AppRoutingMode.DISALLOW -> pluralStringResource(
                            R.plurals.home_routing_disallow,
                            settings.selectedApps.size,
                            settings.selectedApps.size,
                        )
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.End,
                )
            }
        }
    }

    ConnectionFab(
        status = state.status,
        isActive = state.isActive,
        hasProfile = activeProfile != null,
        enabled = fabEnabled,
        onClick = {
            if (activeProfile == null) onNavigateToProfiles() else onToggleConnection(state.isActive)
        },
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(
                end = 16.dp,
                bottom = contentPadding.calculateBottomPadding() + 16.dp,
            ),
    )
    }
    }
}

/**
 * 首页顶部的状态展示区，只读不可点击 —— 连接开关放在右下角的悬浮按钮上。
 *
 * 已连接时向外扩散两道错开半个周期的水波，让"通了"这件事在余光里也能感知到。
 */
@Composable
private fun StatusHero(
    status: VpnStatus,
    statusColor: Color,
    statusLabel: String,
    elapsed: Long,
    hint: String,
    modifier: Modifier = Modifier,
) {
    val connected = status == VpnStatus.CONNECTED
    val transition = rememberInfiniteTransition(label = "hero")
    val wave by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "wave",
    )

    val statusIcon: ImageVector = when (status) {
        VpnStatus.CONNECTED -> Icons.Rounded.VerifiedUser
        VpnStatus.CONNECTING -> Icons.Rounded.Shield
        VpnStatus.ERROR -> Icons.Rounded.GppBad
        VpnStatus.DISCONNECTED -> Icons.Outlined.Shield
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier.size(192.dp),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val outer = size.minDimension / 2f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(statusColor.copy(alpha = 0.20f), Color.Transparent),
                        center = center,
                        radius = outer,
                    ),
                    radius = outer,
                )
                if (connected) {
                    listOf(0f, 0.5f).forEach { phase ->
                        val progress = (wave + phase) % 1f
                        drawCircle(
                            color = statusColor.copy(alpha = 0.32f * (1f - progress)),
                            radius = outer * (0.56f + 0.44f * progress),
                            style = Stroke(width = 1.5.dp.toPx()),
                        )
                    }
                }
            }

            AnimatedContent(
                targetState = status == VpnStatus.CONNECTING,
                transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
                label = "connectingRing",
            ) { connecting ->
                if (connecting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(148.dp),
                        color = statusColor,
                        strokeWidth = 2.dp,
                    )
                }
            }

            Surface(
                shape = CircleShape,
                color = statusColor.copy(alpha = 0.12f),
                contentColor = statusColor,
                border = BorderStroke(1.5.dp, statusColor.copy(alpha = 0.45f)),
                modifier = Modifier.size(132.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    AnimatedContent(
                        targetState = statusIcon,
                        transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
                        label = "statusIcon",
                    ) { icon ->
                        Icon(
                            imageVector = icon,
                            contentDescription = statusLabel,
                            modifier = Modifier.size(56.dp),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        AnimatedContent(
            targetState = statusLabel,
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
            label = "statusLabel",
        ) { label ->
            Text(
                text = label,
                style = MaterialTheme.typography.headlineSmall,
                color = statusColor,
            )
        }
        Spacer(Modifier.height(8.dp))
        // 槽位高度固定为计时胶囊的高度，连接状态切换时内容原地替换，
        // 不会把下方的卡片顶下去
        Box(
            modifier = Modifier.height(30.dp),
            contentAlignment = Alignment.Center,
        ) {
            AnimatedContent(
                targetState = connected,
                transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
                label = "statusSlot",
                contentAlignment = Alignment.Center,
            ) { isConnected ->
                if (isConnected) {
                    Surface(
                        shape = RoundedCornerShape(percent = 50),
                        color = statusColor.copy(alpha = 0.12f),
                        contentColor = statusColor,
                    ) {
                        Text(
                            text = formatDuration(elapsed),
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                        )
                    }
                } else {
                    Text(
                        text = hint,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/** 右下角的连接开关，位置与"添加配置"保持一致，单手就能够到。 */
@Composable
private fun ConnectionFab(
    status: VpnStatus,
    isActive: Boolean,
    hasProfile: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    ExtendedFloatingActionButton(
        // 这版 M3 的 FAB 没有 enabled 参数，在 onClick 里挡掉转场残影的点击
        onClick = { if (enabled) onClick() },
        icon = {
            when {
                status == VpnStatus.CONNECTING -> CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = LocalContentColor.current,
                    strokeWidth = 2.dp,
                )

                !hasProfile -> Icon(Icons.Rounded.Dns, contentDescription = null)
                isActive -> Icon(Icons.Rounded.Stop, contentDescription = null)
                else -> Icon(Icons.Rounded.PlayArrow, contentDescription = null)
            }
        },
        text = {
            Text(
                text = when {
                    !hasProfile -> stringResource(R.string.home_select_profile)
                    status == VpnStatus.CONNECTING -> stringResource(R.string.status_connecting)
                    isActive -> stringResource(R.string.action_disconnect)
                    else -> stringResource(R.string.action_connect)
                },
            )
        },
        containerColor = if (isActive) {
            MaterialTheme.colorScheme.errorContainer
        } else {
            MaterialTheme.colorScheme.primaryContainer
        },
        modifier = modifier,
    )
}
