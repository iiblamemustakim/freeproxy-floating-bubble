package tech.xvanturing.freeproxy

import android.content.Context
import tech.xvanturing.freeproxy.data.AppListRepository
import tech.xvanturing.freeproxy.data.ProxyRepository

/**
 * 极简依赖容器。
 *
 * 这个应用只有一个进程、两个仓库和一个常驻服务，用 Hilt 反而是负担，
 * 手写容器足够且完全可控。
 */
object AppContainer {

    private lateinit var appContext: Context

    val proxyRepository: ProxyRepository by lazy { ProxyRepository(appContext) }

    val appListRepository: AppListRepository by lazy { AppListRepository(appContext) }

    fun init(context: Context) {
        appContext = context.applicationContext
    }
}
