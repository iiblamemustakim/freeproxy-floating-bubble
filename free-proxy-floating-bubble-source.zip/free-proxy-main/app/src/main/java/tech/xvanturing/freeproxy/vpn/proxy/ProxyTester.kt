package tech.xvanturing.freeproxy.vpn.proxy

import android.os.SystemClock
import tech.xvanturing.freeproxy.data.model.ProxyProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.UnknownHostException

sealed interface ProxyTestResult {
    data class Success(val elapsedMillis: Long) : ProxyTestResult
    data class Failure(val reason: String) : ProxyTestResult
}

/**
 * 拿真实握手验证一条配置是否可用。
 *
 * 走的是和隧道完全相同的代码路径（解析地址 → 握手 → CONNECT），
 * 因此地址写错、认证失败、代理拒绝目标这些问题都能在连接之前暴露出来。
 */
object ProxyTester {

    private const val TIMEOUT_MS = 12_000L

    /** 一个稳定可达、只用来验证隧道能否打通的目标，不会真正传输数据。 */
    private const val PROBE_HOST = "1.1.1.1"
    private const val PROBE_PORT = 443

    /**
     * 测试期间隧道通常没有启动，即使启动了本应用也已被排除在隧道之外，
     * 因此这里不需要真正的 protect。
     */
    private val passthroughProtector = object : SocketProtector {
        override fun protect(socket: Socket): Boolean = true
        override fun protect(socket: DatagramSocket): Boolean = true
    }

    suspend fun test(profile: ProxyProfile): ProxyTestResult = withContext(Dispatchers.IO) {
        if (profile.host.isBlank()) return@withContext ProxyTestResult.Failure("请先填写服务器地址")
        if (profile.port !in 1..65535) return@withContext ProxyTestResult.Failure("端口不合法")

        val startedAt = SystemClock.elapsedRealtime()
        try {
            withTimeout(TIMEOUT_MS) {
                val address = InetSocketAddress(
                    InetAddress.getByName(profile.host),
                    profile.port,
                )
                val client = ProxyClient(profile, address, passthroughProtector)
                client.connectTcp(InetAddress.getByName(PROBE_HOST), PROBE_PORT).close()
            }
            ProxyTestResult.Success(SystemClock.elapsedRealtime() - startedAt)
        } catch (e: TimeoutCancellationException) {
            ProxyTestResult.Failure("连接超时，请检查地址与网络")
        } catch (e: UnknownHostException) {
            ProxyTestResult.Failure("无法解析服务器地址：${profile.host}")
        } catch (e: Exception) {
            ProxyTestResult.Failure(e.message ?: e.javaClass.simpleName)
        }
    }
}
