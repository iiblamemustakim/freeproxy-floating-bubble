package tech.xvanturing.freeproxy.vpn.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 构造 → 解析的往返测试。
 * 校验和自检用的是反码和的性质：把包含校验和字段在内的整段重新求和，结果必须为 0。
 */
class PacketCodecTest {

    private val sourceIp = (10 shl 24) or (0 shl 16) or (0 shl 8) or 1
    private val destIp = (93 shl 24) or (184 shl 16) or (216 shl 8) or 34

    @Test
    fun `TCP 包往返解析字段一致`() {
        val buffer = ByteArray(1500)
        val payload = "GET / HTTP/1.1\r\n\r\n".toByteArray()
        val size = PacketBuilder.writeTcp(
            output = buffer,
            sourceIp = sourceIp,
            sourcePort = 443,
            destIp = destIp,
            destPort = 51234,
            sequence = 0xFFFF_FFF0L,
            acknowledgment = 12345L,
            flags = TcpHeader.ACK or TcpHeader.PSH,
            window = 65535,
            payload = payload,
            payloadOffset = 0,
            payloadLength = payload.size,
        )

        val ip = Ipv4Header.parse(buffer, size)
        assertNotNull(ip)
        ip!!
        assertEquals(PROTO_TCP, ip.protocol)
        assertEquals(sourceIp, ip.sourceIp)
        assertEquals(destIp, ip.destIp)
        assertEquals(size, ip.totalLength)

        val tcp = TcpHeader.parse(buffer, ip.headerLength, ip.payloadLength)
        assertNotNull(tcp)
        tcp!!
        assertEquals(443, tcp.sourcePort)
        assertEquals(51234, tcp.destPort)
        assertEquals(0xFFFF_FFF0L, tcp.sequence)
        assertEquals(12345L, tcp.acknowledgment)
        assertTrue(tcp.isAck)
        assertEquals(65535, tcp.window)

        val payloadOffset = ip.headerLength + tcp.dataOffset
        assertEquals(payload.size, size - payloadOffset)
        assertEquals(
            String(payload),
            String(buffer, payloadOffset, payload.size),
        )
    }

    @Test
    fun `IPv4 首部校验和自洽`() {
        val buffer = ByteArray(1500)
        val size = PacketBuilder.writeTcp(
            output = buffer,
            sourceIp = sourceIp,
            sourcePort = 80,
            destIp = destIp,
            destPort = 40000,
            sequence = 1,
            acknowledgment = 1,
            flags = TcpHeader.ACK,
            window = 8192,
        )
        assertEquals(40, size)
        // 含校验和字段一起重新求和，取反后必须归零
        assertEquals(0, Checksum.compute(buffer, 0, Ipv4Header.MIN_SIZE))
    }

    @Test
    fun `TCP 校验和自洽`() {
        val buffer = ByteArray(1500)
        val payload = ByteArray(101) { it.toByte() } // 奇数长度，覆盖补零分支
        val size = PacketBuilder.writeTcp(
            output = buffer,
            sourceIp = sourceIp,
            sourcePort = 8080,
            destIp = destIp,
            destPort = 1234,
            sequence = 7,
            acknowledgment = 9,
            flags = TcpHeader.ACK,
            window = 4096,
            payload = payload,
            payloadOffset = 0,
            payloadLength = payload.size,
        )
        val tcpLength = size - Ipv4Header.MIN_SIZE
        val pseudo = Checksum.pseudoHeaderSum(sourceIp, destIp, PROTO_TCP, tcpLength)
        assertEquals(0, Checksum.compute(buffer, Ipv4Header.MIN_SIZE, tcpLength, pseudo))
    }

    @Test
    fun `SYN-ACK 携带 MSS 选项`() {
        val buffer = ByteArray(1500)
        val size = PacketBuilder.writeTcp(
            output = buffer,
            sourceIp = sourceIp,
            sourcePort = 443,
            destIp = destIp,
            destPort = 55555,
            sequence = 100,
            acknowledgment = 200,
            flags = TcpHeader.SYN or TcpHeader.ACK,
            window = 65535,
            mss = 1460,
        )
        val ip = Ipv4Header.parse(buffer, size)!!
        val tcp = TcpHeader.parse(buffer, ip.headerLength, ip.payloadLength)!!
        assertEquals(24, tcp.dataOffset) // 20 字节首部 + 4 字节 MSS 选项
        assertTrue(tcp.isSyn && tcp.isAck)
        val optionOffset = ip.headerLength + TcpHeader.MIN_SIZE
        assertEquals(2, buffer[optionOffset].toInt()) // kind = MSS
        assertEquals(4, buffer[optionOffset + 1].toInt()) // length
        assertEquals(1460, buffer.u16(optionOffset + 2))
    }

    @Test
    fun `UDP 包往返解析字段一致`() {
        val buffer = ByteArray(1500)
        val payload = ByteArray(53) { (it * 7).toByte() }
        val size = PacketBuilder.writeUdp(
            output = buffer,
            sourceIp = sourceIp,
            sourcePort = 53,
            destIp = destIp,
            destPort = 40404,
            payload = payload,
            payloadOffset = 0,
            payloadLength = payload.size,
        )

        val ip = Ipv4Header.parse(buffer, size)!!
        assertEquals(PROTO_UDP, ip.protocol)
        val udp = UdpHeader.parse(buffer, ip.headerLength, ip.payloadLength)!!
        assertEquals(53, udp.sourcePort)
        assertEquals(40404, udp.destPort)
        assertEquals(payload.size, udp.payloadLength)

        val udpLength = size - Ipv4Header.MIN_SIZE
        val pseudo = Checksum.pseudoHeaderSum(sourceIp, destIp, PROTO_UDP, udpLength)
        assertEquals(0, Checksum.compute(buffer, Ipv4Header.MIN_SIZE, udpLength, pseudo))
    }

    @Test
    fun `分片包与非 IPv4 包被拒绝`() {
        val buffer = ByteArray(1500)
        PacketBuilder.writeTcp(
            output = buffer,
            sourceIp = sourceIp,
            sourcePort = 1,
            destIp = destIp,
            destPort = 2,
            sequence = 0,
            acknowledgment = 0,
            flags = TcpHeader.ACK,
            window = 100,
        )
        // 打上 MF 标志，模拟分片
        buffer.putU16(6, 0x2000)
        assertNull(Ipv4Header.parse(buffer, 40))

        // 版本号改成 6
        buffer.putU8(0, 0x65)
        assertNull(Ipv4Header.parse(buffer, 40))
    }

    @Test
    fun `序列号回绕比较正确`() {
        assertTrue(seqLessThan(0xFFFF_FFF0L, 0x0000_0010L)) // 跨越回绕点
        assertTrue(seqLessThan(100L, 200L))
        assertTrue(!seqLessThan(200L, 100L))
        assertEquals(0x0000_0004L, seqAdvance(0xFFFF_FFFFL, 5))
        assertTrue(seqLessOrEqual(500L, 500L))
    }
}
