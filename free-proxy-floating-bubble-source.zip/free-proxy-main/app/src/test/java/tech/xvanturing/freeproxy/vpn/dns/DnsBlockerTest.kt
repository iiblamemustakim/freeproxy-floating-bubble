package tech.xvanturing.freeproxy.vpn.dns

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import tech.xvanturing.freeproxy.vpn.net.DnsQuestion

class DnsBlockerTest {

    private fun blocker(
        apps: Set<String> = emptySet(),
        domains: Set<String> = emptySet(),
        ip: String = "127.0.0.1",
    ) = DnsBlocker(blockApps = apps, blockDomains = domains, responseIp = ip)

    private fun query(name: String) = DnsQuestion(name, DnsQuestion.TYPE_A)

    @Test
    fun `精确名单命中自身与子域`() {
        val blocker = blocker(domains = setOf("example.com"))
        assertEquals("127.0.0.1", blocker.resolve(query("example.com"), null))
        assertEquals("127.0.0.1", blocker.resolve(query("a.b.example.com"), null))
    }

    @Test
    fun `通配名单只命中子域`() {
        val blocker = blocker(domains = setOf("*.example.com"))
        assertEquals("127.0.0.1", blocker.resolve(query("a.example.com"), null))
        assertNull(blocker.resolve(query("example.com"), null))
    }

    @Test
    fun `匹配忽略大小写与末尾根点`() {
        val blocker = blocker(domains = setOf("Example.COM"))
        assertEquals("127.0.0.1", blocker.resolve(query("EXAMPLE.com."), null))
        assertEquals("127.0.0.1", blocker.resolve(query("WWW.Example.Com"), null))
    }

    @Test
    fun `未命中的查询正常放行`() {
        val blocker = blocker(domains = setOf("example.com"))
        assertNull(blocker.resolve(query("other.com"), null))
        // 标签边界之外的后缀不算子域
        assertNull(blocker.resolve(query("notexample.com"), null))
    }

    @Test
    fun `名单内应用的全部查询都被拦截`() {
        val blocker = blocker(apps = setOf("com.foo.app"))
        assertEquals("0.0.0.0", blocker(apps = setOf("com.foo.app"), ip = "0.0.0.0")
            .resolve(query("anything.net"), "com.foo.app"))
        assertNull(blocker.resolve(query("anything.net"), "com.other.app"))
        // 低版本系统反查不到包名，此时应用规则不生效
        assertNull(blocker.resolve(query("anything.net"), null))
    }

    @Test
    fun `同一域名的重复判定只进一次缓存`() {
        val blocker = blocker(domains = setOf("example.com"))
        assertEquals(0, blocker.cacheSize)
        blocker.resolve(query("example.com"), null)
        blocker.resolve(query("other.com"), null)
        assertEquals(2, blocker.cacheSize)
        // 重复查询命中缓存，结果一致且缓存不再增长
        assertEquals("127.0.0.1", blocker.resolve(query("example.com"), null))
        assertNull(blocker.resolve(query("other.com"), null))
        assertEquals(2, blocker.cacheSize)
    }
}
