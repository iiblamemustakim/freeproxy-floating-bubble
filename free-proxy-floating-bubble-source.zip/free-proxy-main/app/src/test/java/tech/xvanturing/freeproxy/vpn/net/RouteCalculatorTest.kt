package tech.xvanturing.freeproxy.vpn.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteCalculatorTest {

    private fun ip(a: Int, b: Int, c: Int, d: Int): Int =
        (a shl 24) or (b shl 16) or (c shl 8) or d

    private fun List<Route>.covers(address: Int): Boolean = any { route ->
        val mask = if (route.prefixLength == 0) 0 else (-1 shl (32 - route.prefixLength))
        (address and mask) == route.address
    }

    @Test
    fun `默认路由覆盖所有地址`() {
        assertTrue(RouteCalculator.DEFAULT.covers(ip(8, 8, 8, 8)))
        assertTrue(RouteCalculator.DEFAULT.covers(ip(192, 168, 1, 1)))
    }

    @Test
    fun `绕过内网时公网地址仍然进隧道`() {
        val routes = RouteCalculator.BYPASS_PRIVATE
        listOf(
            ip(8, 8, 8, 8),
            ip(1, 1, 1, 1),
            ip(104, 16, 0, 1),
            ip(203, 0, 113, 5),
            ip(172, 15, 255, 255), // 紧邻 172.16/12 下边界
            ip(172, 32, 0, 0), // 紧邻 172.16/12 上边界
            ip(192, 167, 255, 255),
            ip(192, 169, 0, 0),
            ip(9, 255, 255, 255),
            ip(11, 0, 0, 0),
        ).forEach { address ->
            assertTrue("公网地址应进入隧道：${address.toIpv4String()}", routes.covers(address))
        }
    }

    @Test
    fun `绕过内网时私有地址不进隧道`() {
        val routes = RouteCalculator.BYPASS_PRIVATE
        listOf(
            ip(10, 0, 0, 1),
            ip(10, 255, 255, 254),
            ip(172, 16, 0, 1),
            ip(172, 31, 255, 254),
            ip(192, 168, 1, 1),
            ip(127, 0, 0, 1),
            ip(169, 254, 1, 1),
            ip(224, 0, 0, 251), // mDNS
            ip(0, 0, 0, 0),
        ).forEach { address ->
            assertFalse("私有地址不应进入隧道：${address.toIpv4String()}", routes.covers(address))
        }
    }

    @Test
    fun `路由条目数量保持在可接受范围`() {
        // VpnService 对路由条数没有硬性上限，但条目爆炸会拖慢 establish
        assertTrue(
            "路由条数过多：${RouteCalculator.BYPASS_PRIVATE.size}",
            RouteCalculator.BYPASS_PRIVATE.size < 100,
        )
        assertTrue(RouteCalculator.BYPASS_PRIVATE.isNotEmpty())
    }

    @Test
    fun `路由之间互不重叠`() {
        val routes = RouteCalculator.BYPASS_PRIVATE
        for (i in routes.indices) {
            for (j in i + 1 until routes.size) {
                val a = routes[i]
                val b = routes[j]
                val shared = if (a.prefixLength < b.prefixLength) {
                    if (a.prefixLength == 0) 0 else (-1 shl (32 - a.prefixLength))
                } else {
                    if (b.prefixLength == 0) 0 else (-1 shl (32 - b.prefixLength))
                }
                assertEquals(
                    "路由重叠：$a 与 $b",
                    false,
                    (a.address and shared) == (b.address and shared),
                )
            }
        }
    }
}
