package tech.xvanturing.freeproxy.vpn.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream

class DnsResponseTest {

    private fun header(questionCount: Int, flags: Int = 0x0100): ByteArray =
        ByteArrayOutputStream().apply {
            write(0x12); write(0x34) // ID
            write(flags ushr 8); write(flags and 0xFF)
            write(0); write(questionCount)
            write(0); write(0) // ANCOUNT
            write(0); write(0) // NSCOUNT
            write(0); write(0) // ARCOUNT
        }.toByteArray()

    private fun labels(name: String): ByteArray = ByteArrayOutputStream().apply {
        name.split('.').forEach { label ->
            write(label.length)
            write(label.toByteArray(Charsets.US_ASCII))
        }
        write(0)
    }.toByteArray()

    private fun query(name: String, type: Int): ByteArray = ByteArrayOutputStream().apply {
        write(header(questionCount = 1))
        write(labels(name))
        write(0); write(type)
        write(0); write(1) // CLASS IN
    }.toByteArray()

    @Test
    fun `A 查询得到伪造的 A 记录`() {
        val request = query("ads.example.com", DnsQuestion.TYPE_A)
        val response = DnsResponse.buildBlockedResponse(request, request.size, "127.0.0.1")
        assertNotNull(response)
        response!!

        // ID 原样保留，QR 置位，RCODE=0
        assertEquals(0x12, response[0].toInt() and 0xFF)
        assertEquals(0x34, response[1].toInt() and 0xFF)
        assertTrue(response[2].toInt() and 0x80 != 0)
        assertEquals(0, response[3].toInt() and 0x0F)

        val question = DnsMessage.readQuestion(response, 0, response.size)
        assertEquals("ads.example.com", question?.name)
        assertEquals(DnsQuestion.TYPE_A, question?.type)

        val answers = DnsMessage.readAnswers(response, 0, response.size)
        assertEquals(1, answers.size)
        assertEquals("ads.example.com", answers[0].first)
        assertEquals("127.0.0.1", answers[0].second.toIpv4String())
    }

    @Test
    fun `AAAA 查询得到空的 NOERROR 应答`() {
        val request = query("ads.example.com", DnsQuestion.TYPE_AAAA)
        val response = DnsResponse.buildBlockedResponse(request, request.size, "127.0.0.1")
        assertNotNull(response)
        response!!

        assertTrue(response[2].toInt() and 0x80 != 0)
        assertEquals(0, response[6].toInt() and 0xFF) // ANCOUNT 高字节
        assertEquals(0, response[7].toInt() and 0xFF) // ANCOUNT 低字节
        assertTrue(DnsMessage.readAnswers(response, 0, response.size).isEmpty())
    }

    @Test
    fun `查询尾部的附加记录不会混进应答`() {
        // 带 EDNS OPT 附加记录的查询：应答应只保留问题段再加 Answer
        val request = ByteArrayOutputStream().apply {
            write(header(questionCount = 1))
            write(labels("example.com"))
            write(0); write(DnsQuestion.TYPE_A)
            write(0); write(1)
            write(0) // OPT 的根域名
            write(0); write(41) // TYPE OPT
            write(0); write(0) // CLASS（UDP 载荷大小）
            write(0); write(0); write(0); write(0) // TTL
            write(0); write(0) // RDLENGTH
        }.toByteArray()

        val response = DnsResponse.buildBlockedResponse(request, request.size, "10.0.0.1")
        assertNotNull(response)
        val answers = DnsMessage.readAnswers(response!!, 0, response.size)
        assertEquals(1, answers.size)
        assertEquals("10.0.0.1", answers[0].second.toIpv4String())
    }

    @Test
    fun `畸形查询与非法 IP 都返回 null`() {
        assertNull(DnsResponse.buildBlockedResponse(ByteArray(4), 4, "127.0.0.1"))
        val request = query("example.com", DnsQuestion.TYPE_A)
        assertNull(DnsResponse.buildBlockedResponse(request, request.size, "999.1.1.1"))
        assertNull(DnsResponse.buildBlockedResponse(request, request.size, "not-an-ip"))
    }
}
