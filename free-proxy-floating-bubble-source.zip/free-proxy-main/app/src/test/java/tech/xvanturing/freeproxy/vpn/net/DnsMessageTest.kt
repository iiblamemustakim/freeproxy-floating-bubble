package tech.xvanturing.freeproxy.vpn.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream

class DnsMessageTest {

    private fun header(
        questionCount: Int,
        answerCount: Int,
        flags: Int = 0x0100,
    ): ByteArray = ByteArrayOutputStream().apply {
        write(0x12); write(0x34) // ID
        write(flags ushr 8); write(flags and 0xFF)
        write(0); write(questionCount)
        write(0); write(answerCount)
        write(0); write(0) // NSCOUNT
        write(0); write(0) // ARCOUNT
    }.toByteArray()

    private fun labels(name: String): ByteArray = ByteArrayOutputStream().apply {
        name.split('.').forEach { label ->
            write(label.length)
            write(label.toByteArray(Charsets.US_ASCII))
        }
        write(0)
    }.toByteArray()

    private fun query(name: String, type: Int): ByteArray = ByteArrayOutputStream().apply {
        write(header(questionCount = 1, answerCount = 0))
        write(labels(name))
        write(0); write(type)
        write(0); write(1) // CLASS IN
    }.toByteArray()

    @Test
    fun `解析 A 查询的域名与类型`() {
        val packet = query("google.com", DnsQuestion.TYPE_A)
        val question = DnsMessage.readQuestion(packet, 0, packet.size)
        assertEquals("google.com", question?.name)
        assertEquals("A", question?.typeName)
    }

    @Test
    fun `解析 AAAA 与多级子域`() {
        val packet = query("play.googleapis.com", DnsQuestion.TYPE_AAAA)
        val question = DnsMessage.readQuestion(packet, 0, packet.size)
        assertEquals("play.googleapis.com", question?.name)
        assertEquals("AAAA", question?.typeName)
    }

    @Test
    fun `从压缩指针的应答里取出 A 记录`() {
        val packet = ByteArrayOutputStream().apply {
            write(header(questionCount = 1, answerCount = 1, flags = 0x8180))
            write(labels("example.com"))
            write(0); write(DnsQuestion.TYPE_A)
            write(0); write(1)
            // 应答的 NAME 用压缩指针指回问题段（偏移 12）
            write(0xC0); write(0x0C)
            write(0); write(DnsQuestion.TYPE_A)
            write(0); write(1)
            write(0); write(0); write(1); write(0x2C) // TTL
            write(0); write(4) // RDLENGTH
            write(93); write(184); write(216); write(34)
        }.toByteArray()

        val answers = DnsMessage.readAnswers(packet, 0, packet.size)
        assertEquals(1, answers.size)
        assertEquals("example.com", answers[0].first)
        assertEquals("93.184.216.34", answers[0].second.toIpv4String())
    }

    @Test
    fun `跳过非 A 记录`() {
        val packet = ByteArrayOutputStream().apply {
            write(header(questionCount = 1, answerCount = 1, flags = 0x8180))
            write(labels("example.com"))
            write(0); write(DnsQuestion.TYPE_AAAA)
            write(0); write(1)
            write(0xC0); write(0x0C)
            write(0); write(DnsQuestion.TYPE_AAAA)
            write(0); write(1)
            write(0); write(0); write(1); write(0x2C)
            write(0); write(16) // AAAA 的 RDLENGTH
            repeat(16) { write(0) }
        }.toByteArray()

        assertTrue(DnsMessage.readAnswers(packet, 0, packet.size).isEmpty())
    }

    @Test
    fun `畸形报文不会抛异常`() {
        assertNull(DnsMessage.readQuestion(ByteArray(4), 0, 4))
        assertNull(DnsMessage.readQuestion(ByteArray(0), 0, 0))
        // 标签长度越界
        val truncated = ByteArrayOutputStream().apply {
            write(header(questionCount = 1, answerCount = 0))
            write(60) // 声称有 60 字节的标签，实际没有
            write("ab".toByteArray())
        }.toByteArray()
        assertNull(DnsMessage.readQuestion(truncated, 0, truncated.size))
    }

    @Test
    fun `自指的压缩指针不会造成死循环`() {
        val packet = ByteArrayOutputStream().apply {
            write(header(questionCount = 1, answerCount = 0))
            write(0xC0); write(0x0C) // 指向自己所在的位置
            write(0); write(DnsQuestion.TYPE_A)
            write(0); write(1)
        }.toByteArray()

        // 只要能返回（无论 null 还是空名）就说明跳数限制生效了
        DnsMessage.readQuestion(packet, 0, packet.size)
    }

    @Test
    fun `反查表按域名回填并可淘汰`() {
        HostRegistry.clear()
        val address = (140 shl 24) or (82 shl 16) or (121 shl 8) or 4
        HostRegistry.remember(address, "github.com")
        assertEquals("github.com", HostRegistry.lookup(address))
        assertEquals("github.com:443", HostRegistry.describe(address, 443))

        val unknown = (8 shl 24) or (8 shl 16) or (8 shl 8) or 8
        assertEquals("8.8.8.8:53", HostRegistry.describe(unknown, 53))
        HostRegistry.clear()
    }
}
