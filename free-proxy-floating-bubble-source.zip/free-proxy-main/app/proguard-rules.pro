# kotlinx.serialization —— 保留 @Serializable 类生成的序列化器
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**

-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

-keep,includedescriptorclasses class tech.xvanturing.freeproxy.**$$serializer { *; }
-keepclassmembers class tech.xvanturing.freeproxy.** {
    *** Companion;
}
-keepclasseswithmembers class tech.xvanturing.freeproxy.** {
    kotlinx.serialization.KSerializer serializer(...);
}
